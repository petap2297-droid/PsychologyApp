package com.example.myapplication

import android.os.Bundle // ОСНОВНЫЕ ANDROID КОМПОНЕНТЫ
import androidx.activity.ComponentActivity //базовая активность Android
import androidx.activity.compose.setContent //позволяет использовать Compose вместо XML разметки
import androidx.compose.foundation.layout.* //контейнеры, модификаторы размеров,выравнивание
import androidx.compose.material3.*// Button, TextField, Card - кнопки, поля ввода, карточки MaterialTheme - система тем ext, Icon - текст и иконки
import androidx.compose.runtime.* //mutableStateOf()-создание реактивных переменных remember-сохранение состояния между перерисовками LaunchedEffect-запуск побочных эффектов (аналог lifecycle)
import androidx.compose.ui.Alignment//Alignment - выравнивание внутри контейнеров
import androidx.compose.ui.Modifier//цепочка модификаторов внешнего вида
import androidx.compose.ui.unit.dp// единицы измерения (пиксели и scale-independent pixels)
import androidx.compose.foundation.clickable//делает любой элемент кликабельным
import androidx.compose.ui.graphics.Color// работа с цветами
import androidx.compose.ui.text.font.FontWeight //жирность текста
import androidx.compose.ui.text.style.TextAlign//выравнивание текста (Center)
import androidx.compose.foundation.background// фон элементов
import androidx.compose.ui.platform.LocalContext//Доступ к контексту Android (для Toast, ресурсов и тд)
import androidx.compose.ui.unit.sp//единицы измерения (пиксели и scale-independent pixels)
import androidx.compose.foundation.lazy.LazyColumn//оптимизированный список (подгружает только видимые элементы)
import androidx.compose.foundation.lazy.items//рендеринг элементов списка
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.material.icons.Icons// набор готовых иконок Material Design
import androidx.compose.material3.IconButton//кнопка с иконкой
import androidx.compose.material3.Icon //отображение иконки
import androidx.compose.material3.darkColorScheme// Готовые цветовые схемы для светлой и темной тем
import androidx.compose.material3.lightColorScheme// Готовые цветовые схемы для светлой и темной тем
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.BorderStroke//границы элементов
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.ModalNavigationDrawer//контейнер меню
import androidx.compose.material3.ModalDrawerSheet//содержимое меню
import androidx.compose.material3.NavigationDrawerItem// пункты меню
import androidx.compose.material3.Divider
import androidx.compose.material3.DrawerValue// состояние меню (открыто/закрыто)
import androidx.compose.material3.rememberDrawerState
import kotlinx.coroutines.launch//launch - запуск асинхронных операций
import androidx.compose.runtime.rememberCoroutineScope//область видимости для корутин в Compose
import androidx.compose.ui.text.font.FontStyle //fontStyle - стиль текста
import androidx.compose.ui.text.input.PasswordVisualTransformation//скрытие пароля (звездочки)

data class TestResult(
    val id: Int,
    val studentId: Int,
    val studentName: String,
    val score: Int,
    val date: String,
    val answers: List<Int>,
    val recommendations: String
)
// Добавим в начало файла, рядом с data class Student
data class ChatMessage(
    val id: String,
    val senderId: Int,        // ID отправителя
    val receiverId: Int,      // ID получателя
    val senderName: String,   // Имя отправителя
    val message: String,      // Текст сообщения
    val timestamp: Long,      // Время отправки
    val isRead: Boolean = false
)

data class Chat(
    val chatId: String,
    val studentId: Int,
    val studentName: String,
    val lastMessage: String,
    val lastMessageTime: Long,
    val unreadCount: Int = 0
)

// ДАННЫЕ ДЛЯ УПРАВЛЕНИЯ ТЕМОЙ
enum class ColorTheme { LIGHT, DARK }

@Composable
fun rememberAppThemeState() = remember {
    mutableStateOf(ColorTheme.LIGHT)
}
// МОДЕЛЬ ДАННЫХ УЧЕНИКА
data class Student(
    val id: Int,
    val firstName: String,
    val lastName: String,
    val testScore: Int? = null, // последний результат
    val testHistory: List<TestResult> = emptyList(), // ← ДОБАВЛЯЕМ ИСТОРИЮ
    val lastActive: String = "Сегодня",
    val hasUnreadMessages: Boolean = false
)
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { //
            MaterialTheme { //// ↓ Применяем тему Material Design
                // Показываем главный экран приложения
                PsychologyApp()
            }
        }
    }
}
//primary = Color(0xFF2196F3)Яркий синий
//primary = Color(0xFF00BCD4) Бирюзовый
//primary = Color(0xFFFF9800)  оранжевый
//primary = Color(0xFF7E57C2)  фиолетовый
@Composable
fun MyAppTheme(
    darkTheme: Boolean = false,
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) {
        // ТЕМНАЯ ТЕМА
        darkColorScheme(
            primary = Color(0xFFBB86FC),
            onPrimary = Color(0xFF000000),
            primaryContainer = Color(0xFF3700B3),
            onPrimaryContainer = Color(0xFFEADDFF),
            secondary = Color(0xFF03DAC6),
            onSecondary = Color(0xFF000000),
            background = Color(0xFF121212),       // Тёмный фон
            onBackground = Color(0xFFFFFFFF),     // Белый текст на тёмном
            surface = Color(0xFF1E1E1E),          // Тёмные карточки
            onSurface = Color(0xFFFFFFFF),        // Белый текст на карточках
            surfaceVariant = Color(0xFF2D2D2D),
            onSurfaceVariant = Color(0xFFC8C8C8)
        )
    } else {
        // СВЕТЛАЯ ТЕМА
        lightColorScheme(
            primary = Color(0xFF6A5AE0),
            onPrimary = Color(0xFFFFFFFF),
            primaryContainer = Color(0xFFE8E6FF),
            onPrimaryContainer = Color(0xFF1A0061),
            secondary = Color(0xFF625B71),
            onSecondary = Color(0xFFFFFFFF),
            background = Color(0xFFF5F7FF),       // Светлый фон
            onBackground = Color(0xFF1C1B1F),     // Тёмный текст на светлом
            surface = Color(0xFFFFFFFF),          // Белые карточки
            onSurface = Color(0xFF1C1B1F),        // Тёмный текст на карточках
            surfaceVariant = Color(0xFFE7E0EC),
            onSurfaceVariant = Color(0xFF49454F)
        )
    }
    MaterialTheme(
        colorScheme = colorScheme,
        typography = MaterialTheme.typography,
        content = content
    )
}
// Главное приложение, которое управляет экранами
@Composable
fun PsychologyApp() {
    val themeState = rememberAppThemeState()
    var currentScreen by remember { mutableStateOf("registration") }
    var selectedUserRole by remember { mutableStateOf(0) }
    var currentStudentChat by remember { mutableStateOf<Pair<Int, String>?>(null) }
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    var currentTeacherChat by remember { mutableStateOf<Pair<Int, String>?>(null) }
    var currentStudentForHistory by remember { mutableStateOf<Student?>(null) }
    // ПРОСТЫЕ ПЕРЕМЕННЫЕ ДЛЯ ДАННЫХ
    var userTestScore by remember { mutableStateOf(0) }
    var currentUserName by remember { mutableStateOf("Ученик") }



    fun openDrawer() {
        scope.launch { drawerState.open() }
    }

    fun closeDrawer() {
        scope.launch { drawerState.close() }
    }
    var testHistory by remember {
        mutableStateOf<List<TestResult>>(emptyList())
    }


    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet {
                Text(
                    text = "Меню",
                    modifier = Modifier.padding(16.dp),
                    style = MaterialTheme.typography.headlineSmall,
                    color = MaterialTheme.colorScheme.primary
                )

                Divider()

                NavigationDrawerItem(
                    label = { Text("👥 Сменить роль") },
                    selected = false,
                    onClick = {
                        currentScreen = "registration"
                        closeDrawer()
                    }
                )

                // ОБНОВЛЯЕМ НАДПИСЬ В ЗАВИСИМОСТИ ОТ ТЕКУЩЕЙ ТЕМЫ
                NavigationDrawerItem(
                    label = {
                        Text(
                            if (themeState.value == ColorTheme.DARK) "☀️ Светлая тема" else "🌙 Тёмная тема"
                        )
                    },
                    selected = false,
                    onClick = {
                        themeState.value = if (themeState.value == ColorTheme.LIGHT) ColorTheme.DARK else ColorTheme.LIGHT
                        closeDrawer()
                    }
                )

                NavigationDrawerItem(
                    label = { Text("⚙️ Панель администратора") },
                    selected = false,
                    onClick = {
                        currentScreen = "admin_registration"
                        closeDrawer()
                    }
                )
                Spacer(modifier = Modifier.weight(1f))
                Text(
                    text = "Психологический помощник v0.4",
                    modifier = Modifier.padding(16.dp),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    ) {
        // ОСНОВНОЕ СОДЕРЖИМОЕ
        when (currentScreen) {
            "registration" -> RegistrationScreen(
                onStartTest = {
                    // СОХРАНЯЕМ ИМЯ В ГЛОБАЛЬНОЕ СОСТОЯНИЕ
                    // Пока временно - позже добавим передачу из полей ввода
                    currentUserName = "Тестовый Ученик" // ВРЕМЕННО ЗАТВЕРЖДЕННОЕ ИМЯ
                    when (selectedUserRole) {
                        0 -> currentScreen = "test"
                        1 -> currentScreen = "teacher"
                        2 -> currentScreen = "admin_registration"
                        else -> currentScreen = "test"
                    }
                },
                onRoleSelected = { role -> selectedUserRole = role },
                onMenuClick = { openDrawer() }
            )
            "test" -> PsychologyTestScreen(
                onBackToMain = { currentScreen = "registration" },
                onMenuClick = { openDrawer() },
                onTestCompleted = { score ->
                    userTestScore = score

                    // СОЗДАЕМ НОВЫЙ РЕЗУЛЬТАТ ТЕСТА
                    val newTestResult = TestResult(
                        id = (System.currentTimeMillis() % 100000).toInt(),
                        studentId = 0,
                        studentName = currentUserName,
                        score = score,
                        date = getCurrentDateTime(),
                        answers = List(10) { 2 }, // временно тестовые ответы
                        recommendations = getAdviceBasedOnScore(score)
                    )

                    // ВАЖНО: ОБНОВЛЯЕМ ИСТОРИЮ ПРАВИЛЬНО
                    testHistory = testHistory + newTestResult

                    // ДЛЯ ПРОВЕРКИ: выведем в консоль
                    println("✅ Добавлен новый тест в историю: ${newTestResult.score} баллов")
                    println("📊 Всего тестов в истории: ${testHistory.size}")

                    currentScreen = "personal_advice"
                }
            )
            "teacher" -> TeacherScreen(
                onBackToMain = { currentScreen = "registration" },
                onMenuClick = { openDrawer() },
                onOpenChatList = { currentScreen = "teacher_chat_list" },
                onOpenChatWithStudent = { studentId, studentName ->
                    currentStudentChat = Pair(studentId, studentName)
                    currentScreen = "chat"
                },
                onViewStudentHistory = { student ->
                    currentStudentForHistory = student
                    currentScreen = "student_history"
                }
            )
            "admin_registration" -> AdminRegistrationScreen(
                onBackToMain = { currentScreen = "registration" },
                onAdminRegistered = { currentScreen = "admin" }
            )
            "admin" -> AdminScreen(
                onBackToMain = { currentScreen = "registration" },
                onMenuClick = { openDrawer() }
            )
            "teacher_chat_list" -> TeacherChatListScreen(
                onBackToMain = { currentScreen = "registration" },
                onOpenChat = { studentId, studentName ->
                    currentStudentChat = Pair(studentId, studentName)
                    currentScreen = "chat"
                },
                onMenuClick = { openDrawer() }
            )
            "chat" -> {
                val (studentId, studentName) = currentStudentChat ?: Pair(0, "Неизвестный студент")
                ChatScreen(
                    studentId = studentId,
                    studentName = studentName,
                    onBack = { currentScreen = "teacher_chat_list" },
                    onMenuClick = { openDrawer() }
                )
            }
            "personal_advice" -> PersonalAdviceScreen(
                userName = "Ученик",
                userScore = userTestScore,
                onStartChat = { currentScreen = "student_chat_list" },
                onBackToMain = { currentScreen = "registration" },
                onViewHistory = { currentScreen = "my_history" } // ← ДОБАВЛЯЕМ
            )
            "student_chat_list" -> StudentChatListScreen(
                onBackToMain = { currentScreen = "personal_advice" },
                onOpenChat = { teacherId, teacherName ->
                    currentTeacherChat = Pair(teacherId, teacherName)
                    currentScreen = "student_chat"
                },
                onMenuClick = { openDrawer() }
            )
            "student_chat" -> {
                val (teacherId, teacherName) = currentTeacherChat ?: Pair(0, "Учитель")
                StudentChatScreen(
                    teacherId = teacherId,
                    teacherName = teacherName,
                    onBack = { currentScreen = "student_chat_list" },
                    onMenuClick = { openDrawer() },
                    onRetakeTest = {
                        // ПЕРЕХОДИМ ОБРАТНО К ТЕСТУ
                        currentScreen = "test"
                    }
                )
            }
            "student_history" -> {
                val student = currentStudentForHistory ?: Student(
                    id = 0,
                    firstName = "Неизвестный",
                    lastName = "Ученик",
                    testHistory = emptyList() // временно пустая история
                )
                StudentTestHistoryScreen(
                    studentName = "${student.firstName} ${student.lastName}",
                    testHistory = student.testHistory, // используем историю из студента
                    onBack = { currentScreen = "teacher" },
                    onMenuClick = { openDrawer() }
                )
            }
            "my_history" -> StudentTestHistoryScreen(
                studentName = currentUserName,
                testHistory = testHistory, // ← ПЕРЕДАЕМ РЕАЛЬНУЮ ИСТОРИЮ
                onBack = { currentScreen = "personal_advice" },
                onMenuClick = { openDrawer() }
            )
        }
    }
}
// ЭКРАН РЕГИСТРАЦИИ
@Composable
fun RegistrationScreen(
    onStartTest: () -> Unit, // ← ПРОСТОЙ ВАРИАНТ БЕЗ ПАРАМЕТРОВ
    onRoleSelected: (Int) -> Unit = {},
    onMenuClick: () -> Unit
) {
    var firstName by remember { mutableStateOf("") }
    var lastName by remember { mutableStateOf("") }
    var selectedRole by remember { mutableStateOf(0) }

    LaunchedEffect(selectedRole) {
        onRoleSelected(selectedRole)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF5F7FF))
    ) {
        // ШАПКА С КНОПКОЙ МЕНЮ
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Кнопка меню (три полоски)
            IconButton(onClick = onMenuClick) {
                Icon(
                    imageVector = Icons.Default.Menu,
                    contentDescription = "Меню",
                    tint = Color(0xFF6A5AE0)
                )
            }

            Text(
                text = "Регистрация",
                style = MaterialTheme.typography.headlineSmall,
                color = Color(0xFF6A5AE0)
            )

            // ПУСТОЙ ЭЛЕМЕНТ ДЛЯ ВЫРАВНИВАНИЯ (вместо кнопки темы)
            Spacer(modifier = Modifier.size(48.dp))
        }

        // ОСНОВНОЙ КОНТЕНТ
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp),
            verticalArrangement = Arrangement.Center, // ← ИСПОЛЬЗУЕМ Center вместо weight
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Заголовок
            Text(
                text = "👋 Добро пожаловать!",
                style = MaterialTheme.typography.headlineLarge,
                color = Color(0xFF6A5AE0),
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth()
            )

            Text(
                text = "Психологический помощник",
                style = MaterialTheme.typography.bodyLarge,
                color = Color(0xFF6A5AE0).copy(alpha = 0.8f),
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(32.dp))

            // Карточка с формой
            Card(
                modifier = Modifier.fillMaxWidth(),
                elevation = CardDefaults.cardElevation(4.dp)
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    verticalArrangement = Arrangement.spacedBy(20.dp)
                ) {
                    // Поля ввода
                    OutlinedTextField(
                        value = firstName,
                        onValueChange = { firstName = it },
                        label = { Text("Имя") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = TextFieldDefaults.colors(
                            focusedIndicatorColor = Color(0xFF6A5AE0),
                            unfocusedIndicatorColor = Color(0xFF6A5AE0).copy(alpha = 0.5f)
                        )
                    )

                    OutlinedTextField(
                        value = lastName,
                        onValueChange = { lastName = it },
                        label = { Text("Фамилия") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = TextFieldDefaults.colors(
                            focusedIndicatorColor = Color(0xFF6A5AE0),
                            unfocusedIndicatorColor = Color(0xFF6A5AE0).copy(alpha = 0.5f)
                        )
                    )

                    // Выбор роли
                    Text(
                        text = "Выберите роль:",
                        style = MaterialTheme.typography.bodyMedium
                    )

                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        RoleButton(
                            text = "🎓 Ученик",
                            isSelected = selectedRole == 0,
                            onClick = { selectedRole = 0 }
                        )

                        RoleButton(
                            text = "👨‍🏫 Учитель",
                            isSelected = selectedRole == 1,
                            onClick = { selectedRole = 1 }
                        )
                    }
                    // Кнопка регистрации
                    Button(
                        onClick = {
                            if (firstName.isNotEmpty() && lastName.isNotEmpty()) {
                                // ПРОСТО ВЫЗЫВАЕМ onStartTest
                                onStartTest()
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFF6A5AE0)
                        ),
                        enabled = firstName.isNotEmpty() && lastName.isNotEmpty()
                    ) {
                        Text("Начать тест 🚀", color = Color.White)
                    }
                }
            }
        }
    }
}
@Composable
fun RoleButton(text: String, isSelected: Boolean, onClick: () -> Unit) { //Создаем переиспользуемый компонент кнопки роли
    val backgroundColor = if (isSelected) MaterialTheme.colorScheme.primary.copy(alpha = 0.1f) else Color.Transparent // проверяем выбрана ли кнопка если да то берем основной цвет темы .Если нет полностью прозрачный фон
    val borderColor = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline//Если выбрана: Основной цвет темы . Если не выбрана: MaterialTheme.colorScheme.outline - стандартный цвет границы (серый)
    val textColor = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() },
        elevation = if (isSelected) CardDefaults.cardElevation(4.dp) else CardDefaults.cardElevation(1.dp),
        colors = CardDefaults.cardColors(containerColor = backgroundColor),
        border = BorderStroke(1.dp, borderColor)
    ) {
        Row(
            modifier = Modifier.padding(16.dp), // Отступы вокруг всей строки
            verticalAlignment = Alignment.CenterVertically // Выравнивание по центру по вертикали
        ) {
            RadioButton(
                selected = isSelected, // Состояние выбора (true/false)
                onClick = onClick,  // Обработчик клика
                colors = RadioButtonDefaults.colors(
                    selectedColor = MaterialTheme.colorScheme.primary // Цвет выбранной кнопки
                )
            )
            Text(
                text = text, // Текст кнопки
                modifier = Modifier.padding(start = 8.dp),// Отступ слева от RadioButton
                color = textColor,  // Цвет текста (зависит от выбора)
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal  // Жирность текста
            )
        }
    }
}
// Отдельная функция для кнопок ролей (чтобы не повторять код)
// ЭКРАН ПСИХОЛОГИЧЕСКОГО ТЕСТА (ИСПРАВЛЕННАЯ ВЕРСИЯ)
@Composable
fun PsychologyTestScreen(
    onBackToMain: () -> Unit,
    onMenuClick: () -> Unit,
    onTestCompleted: (Int) -> Unit,
    studentName: String = "Ученик"
) {

    // Список вопросов для теста
    val questions = listOf(
        "1. Я часто чувствую себя спокойно и расслабленно",
        "2. Мне легко знакомиться с новыми людьми",
        "3. Я часто переживаю из-за мелочей",
        "4. Мне нравится работать в команде",
        "5. Я часто чувствую усталость без причины",
        "6. Мне легко принимать решения",
        "7. Я часто критикую себя",
        "8. Я легко адаптируюсь к изменениям",
        "9. Мне трудно сказать 'нет'",
        "10. Я доволен(льна) своей жизнью"
    )
    // Текущий вопрос (от 0 до 9)
    var currentQuestion by remember { mutableStateOf(0) }
    // Ответы пользователя
    var answers by remember { mutableStateOf(List(10) { -1 }) }
    // Показывать ли результат
    var showResult by remember { mutableStateOf(false) }
    // Если показываем результат
    if (showResult) {
        TestResultScreen(
            answers = answers,
            onBackToMain = {
                val totalScore = answers.sum()

                // ДОБАВЛЯЕМ СОЗДАНИЕ РЕЗУЛЬТАТА ТЕСТА
                val newTestResult = TestResult(
                    id = (System.currentTimeMillis() % 100000).toInt(),
                    studentId = 0,
                    studentName = studentName,
                    score = totalScore,
                    date = getCurrentDateTime(),
                    answers = answers, // ← СОХРАНЯЕМ ОТВЕТЫ
                    recommendations = getAdviceBasedOnScore(totalScore)
                )

                // ДОБАВЬТЕ ЭТУ СТРОЧКУ ДЛЯ ОТЛАДКИ:
                println("🎯 Тест завершен: $totalScore баллов")

                // Передаем только score, как было раньше
                onTestCompleted(totalScore)
            }
        )
        return
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.White)
    ) {
        // ШАПКА С КНОПКОЙ МЕНЮ И НАЗАД
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Кнопка меню (три полоски)
            IconButton(onClick = onMenuClick) {
                Icon(
                    imageVector = Icons.Default.Menu,
                    contentDescription = "Меню",
                    tint = Color(0xFF6A5AE0)
                )
            }

            Text(
                text = "Психологический тест",
                style = MaterialTheme.typography.headlineSmall,
                color = Color(0xFF6A5AE0)
            )

            // Кнопка назад
            IconButton(onClick = onBackToMain) {
                Icon(
                    imageVector = Icons.Default.ArrowBack,
                    contentDescription = "Назад",
                    tint = Color(0xFF6A5AE0)
                )
            }
        }

        // ОСНОВНОЙ КОНТЕНТ
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .padding(24.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Прогресс бар
            Text(
                text = "Вопрос ${currentQuestion + 1}/10",
                style = MaterialTheme.typography.bodySmall,
                color = Color.Gray
            )

            LinearProgressIndicator(
                progress = (currentQuestion + 1) / 10f,
                modifier = Modifier.fillMaxWidth(),
                color = Color(0xFF6A5AE0)
            )

            // Текст вопроса
            Text(
                text = questions[currentQuestion],
                style = MaterialTheme.typography.headlineSmall,
                modifier = Modifier.fillMaxWidth()
            )

            // Варианты ответов
            Text("Насколько это похоже на вас?")

            val options = listOf(
                "Совсем не похоже" to 0,
                "Скорее не похоже" to 1,
                "Затрудняюсь ответить" to 2,
                "Скорее похоже" to 3,
                "Очень похоже" to 4
            )

            options.forEach { (text, value) ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable {
                            val newAnswers = answers.toMutableList()
                            newAnswers[currentQuestion] = value
                            answers = newAnswers
                        },
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    RadioButton(
                        selected = answers[currentQuestion] == value,// ← ПРОВЕРКА ВЫБРАН ЛИ ОТВЕТ
                        onClick = {
                            val newAnswers = answers.toMutableList()
                            newAnswers[currentQuestion] = value
                            answers = newAnswers
                        },
                        colors = RadioButtonDefaults.colors(
                            selectedColor = Color(0xFF6A5AE0)
                        )
                    )
                    Text(
                        text = text, // ← ТЕКСТ ВАРИАНТА
                        modifier = Modifier.padding(start = 8.dp)// ← ОТСТУП ОТ RadioButton
                    )
                }
            }
        }

        // КНОПКИ НАВИГАЦИИ
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // Кнопка "Назад"
            if (currentQuestion > 0) {
                Button(
                    onClick = { currentQuestion-- },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color.LightGray
                    )
                ) {
                    Text("Назад", color = Color.Black)
                }
            } else {
                Spacer(modifier = Modifier.width(80.dp))
            }

            // Кнопка "Далее" или "Завершить"
            if (currentQuestion < 9) {
                Button(
                    onClick = { currentQuestion++ },
                    enabled = answers[currentQuestion] != -1,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFF6A5AE0)
                    )
                ) {
                    Text("Далее", color = Color.White)
                }
            } else {
                Button(
                    onClick = { showResult = true },
                    enabled = answers[currentQuestion] != -1,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFF6A5AE0)
                    )
                ) {
                    Text("Завершить тест", color = Color.White)
                }
            }
        }
    }
}
// ЭКРАН РЕЗУЛЬТАТОВ ТЕСТА (ОБНОВЛЁННАЯ)
@Composable
fun TestResultScreen(
    answers: List<Int>,
    onBackToMain: () -> Unit
) {
    val totalScore = answers.sum()
    val resultText = when {
        totalScore <= 15 -> "Низкий уровень эмоционального благополучия. Рекомендуется обратиться к психологу."
        totalScore <= 25 -> "Средний уровень. Есть над чем работать, но в целом стабильное состояние."
        else -> "Высокий уровень эмоционального благополучия. Продолжайте в том же духе!"
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp)
            .background(Color.White),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = "Результаты теста",
            style = MaterialTheme.typography.headlineMedium
        )

        Spacer(modifier = Modifier.height(32.dp))

        Card(
            modifier = Modifier.fillMaxWidth(),
            elevation = CardDefaults.cardElevation(4.dp)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("Ваш результат:")
                Text(
                    text = "$totalScore/40 баллов",
                    style = MaterialTheme.typography.headlineMedium,
                    color = Color(0xFF6A5AE0)
                )
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        Text(
            text = resultText,
            style = MaterialTheme.typography.bodyLarge,
            modifier = Modifier.fillMaxWidth(),
            textAlign = TextAlign.Center
        )

        Spacer(modifier = Modifier.height(32.dp))

        // ИЗМЕНЯЕМ КНОПКУ - она должна передавать результат, а не просто возвращать
        Button(
            onClick = {
                // ВЫЗЫВАЕМ onBackToMain КОТОРЫЙ ПЕРЕДАСТ РЕЗУЛЬТАТ
                onBackToMain()
            },
            modifier = Modifier
                .fillMaxWidth()
                .height(50.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = Color(0xFF6A5AE0)
            )
        ) {
            Text("Посмотреть персональные рекомендации", color = Color.White)
        }

        Spacer(modifier = Modifier.height(16.dp))

        // ДОБАВЛЯЕМ КНОПКУ ДЛЯ ВОЗВРАТА НА ГЛАВНУЮ (если нужно)
        TextButton(
            onClick = {
                // Здесь нужна дополнительная логика для возврата на главную
                // Пока оставим пустым или уберем
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Вернуться на главную", color = Color.Gray)
        }
    }
}
// ЭКРАН УЧИТЕЛЯ - ПОЛНАЯ ВЕРСИЯ (ИСПРАВЛЕННАЯ)
@Composable
fun TeacherScreen(
    onBackToMain: () -> Unit,
    onMenuClick: () -> Unit,
    onOpenChatList: () -> Unit,
    onOpenChatWithStudent: (Int, String) -> Unit,
    onViewStudentHistory: (Student) -> Unit
) {
    val context = LocalContext.current

    // ОСТАВЬТЕ ЭТО - это важно!
    val students = remember {
        listOf(
            Student(
                id = 1,
                firstName = "Анна",
                lastName = "Иванова",
                testScore = 28,
                testHistory = listOf(
                    TestResult(1, 1, "Анна Иванова", 28, "15.12.2023 14:30", listOf(3,2,4,1,2,3,4,2,1,3), "Стабильное состояние"),
                    TestResult(2, 1, "Анна Иванова", 25, "10.12.2023 10:15", listOf(2,3,3,2,1,2,3,3,2,2), "Небольшой прогресс")
                ),
                lastActive = "Сегодня",
                hasUnreadMessages = true
            ),
            Student(
                id = 2,
                firstName = "Максим",
                lastName = "Петров",
                testScore = 32,
                testHistory = listOf(
                    TestResult(3, 2, "Максим Петров", 32, "14.12.2023 16:45", listOf(4,3,2,4,3,4,3,4,3,4), "Отличный результат")
                ),
                lastActive = "Вчера",
                hasUnreadMessages = false
            ),
            Student(
                id = 3,
                firstName = "София",
                lastName = "Сидорова",
                testScore = null,
                testHistory = emptyList(),
                lastActive = "2 дня назад",
                hasUnreadMessages = true
            ),
            Student(
                id = 4,
                firstName = "Дмитрий",
                lastName = "Кузнецов",
                testScore = 19,
                testHistory = listOf(
                    TestResult(4, 4, "Дмитрий Кузнецов", 19, "13.12.2023 09:20", listOf(1,2,1,2,1,2,1,2,1,2), "Требуется внимание")
                ),
                lastActive = "Неделю назад",
                hasUnreadMessages = false
            ),
            Student(
                id = 5,
                firstName = "Елена",
                lastName = "Смирнова",
                testScore = 35,
                testHistory = listOf(
                    TestResult(5, 5, "Елена Смирнова", 35, "12.12.2023 11:30", listOf(4,4,3,4,4,3,4,4,4,3), "Превосходный результат")
                ),
                lastActive = "Сегодня",
                hasUnreadMessages = false
            )
        )
    }

    var searchText by remember { mutableStateOf("") }
    val filteredStudents = students.filter { student ->
        student.firstName.contains(searchText, ignoreCase = true) ||
                student.lastName.contains(searchText, ignoreCase = true)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF5F7FF))
    ) {
        // ШАПКА
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onMenuClick) {
                Icon(Icons.Default.Menu, "Меню", tint = Color(0xFF6A5AE0))
            }

            Text(
                text = "Панель учителя",
                style = MaterialTheme.typography.headlineSmall,
                color = Color(0xFF6A5AE0)
            )

            IconButton(onClick = onBackToMain) {
                Icon(Icons.Default.ArrowBack, "Назад", tint = Color(0xFF6A5AE0))
            }
        }

        // КАРТОЧКА С ПОИСКОМ
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            elevation = CardDefaults.cardElevation(4.dp)
        ) {
            Column(
                modifier = Modifier.padding(16.dp)
            ) {
                Text(
                    text = "Учеников: ${students.size}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = Color.Gray
                )

                Spacer(modifier = Modifier.height(16.dp))

                OutlinedTextField(
                    value = searchText,
                    onValueChange = { searchText = it },
                    label = { Text("🔍 Поиск ученика...") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }

        // СПИСОК УЧЕНИКОВ
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(filteredStudents) { student ->
                StudentCard(
                    student = student,
                    onChatClick = {
                        onOpenChatWithStudent(student.id, "${student.firstName} ${student.lastName}")
                    },
                    onViewHistory = {
                        onViewStudentHistory(student) // ← ТЕПЕРЬ ЧЕРЕЗ КОЛБЭК
                    }
                )
            }
        }

        // КНОПКИ
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Button(
                onClick = onOpenChatList,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFF6A5AE0)
                )
            ) {
                Text("💬 Перейти к чатам", color = Color.White)
            }
            Button(
                onClick = onBackToMain,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color.LightGray
                )
            ) {
                Text("Вернуться на главную", color = Color.Black)
            }
        }
    }
}

// КАРТОЧКА УЧЕНИКА В СПИСКЕ
// Обновим StudentCard для учителя
@Composable
fun StudentCard(
    student: Student,
    onChatClick: () -> Unit,
    onViewHistory: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onChatClick() },
        elevation = CardDefaults.cardElevation(2.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // ИНФОРМАЦИЯ ОБ УЧЕНИКЕ
                Column(modifier = Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "${student.firstName} ${student.lastName}",
                            style = MaterialTheme.typography.bodyLarge,
                            fontWeight = FontWeight.Bold
                        )
                        if (student.hasUnreadMessages) {
                            Spacer(modifier = Modifier.width(8.dp))
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .background(Color.Red, CircleShape)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    // ПОСЛЕДНИЙ РЕЗУЛЬТАТ
                    if (student.testScore != null) {
                        val scoreColor = when {
                            student.testScore <= 15 -> Color(0xFFE53935)
                            student.testScore <= 25 -> Color(0xFFFB8C00)
                            else -> Color(0xFF43A047)
                        }
                        Text(
                            text = "Последний тест: ${student.testScore}/40",
                            style = MaterialTheme.typography.bodyMedium,
                            color = scoreColor
                        )
                    } else {
                        Text(
                            text = "Тест не пройден",
                            style = MaterialTheme.typography.bodyMedium,
                            color = Color.Gray
                        )
                    }

                    // ИСТОРИЯ ТЕСТОВ
                    if (student.testHistory.isNotEmpty()) {
                        Text(
                            text = "Всего тестов: ${student.testHistory.size}",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color.Gray
                        )
                    }
                }

                // КНОПКИ
                Column {
                    Button(
                        onClick = onChatClick,
                        modifier = Modifier
                            .height(36.dp)
                            .padding(bottom = 4.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFF6A5AE0)
                        )
                    ) {
                        Text("💬 Чат", fontSize = 12.sp)
                    }

                    // КНОПКА ПРОСМОТРА ИСТОРИИ
                    Button(
                        onClick = onViewHistory,
                        modifier = Modifier.height(36.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFF4CAF50)
                        )
                    ) {
                        Text("📊 История", fontSize = 12.sp)
                    }
                }
            }

            Spacer(modifier = Modifier.height(4.dp))

            // ПОСЛЕДНЯЯ АКТИВНОСТЬ
            Text(
                text = "Был(а) в сети: ${student.lastActive}",
                style = MaterialTheme.typography.bodySmall,
                color = Color.Gray
            )
        }
    }
}

@Composable
fun AdminScreen(
    onBackToMain: () -> Unit,
    onMenuClick: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF5F7FF))
    ) {
        // ШАПКА С КНОПКОЙ МЕНЮ И НАЗАД
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Кнопка меню (три полоски)
            IconButton(onClick = onMenuClick) {
                Icon(
                    imageVector = Icons.Default.Menu,
                    contentDescription = "Меню",
                    tint = Color(0xFF6A5AE0)
                )
            }

            Text(
                text = "Панель администратора",
                style = MaterialTheme.typography.headlineSmall,
                color = Color(0xFF6A5AE0)
            )

            // Кнопка назад
            IconButton(onClick = onBackToMain) {
                Icon(
                    imageVector = Icons.Default.ArrowBack,
                    contentDescription = "Назад",
                    tint = Color(0xFF6A5AE0)
                )
            }
        }

        // ОСНОВНОЙ КОНТЕНТ
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .padding(24.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "⚙️ Панель администратора",
                style = MaterialTheme.typography.headlineMedium,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(32.dp))

            Text(
                text = "Здесь будут все права управления приложением",
                style = MaterialTheme.typography.bodyLarge,
                textAlign = TextAlign.Center
            )
        }

        // КНОПКА НАЗАД
        Button(
            onClick = onBackToMain,
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .height(50.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = Color(0xFF6A5AE0)
            )
        ) {
            Text("Вернуться на главную", color = Color.White)
        }
    }
}

@Composable
fun AdminRegistrationScreen(
    onBackToMain: () -> Unit,
    onAdminRegistered: () -> Unit  // ← После успешной регистрации переходим в админ-панель
) {
    var adminName by remember { mutableStateOf("") }
    var adminEmail by remember { mutableStateOf("") }
    var adminPassword by remember { mutableStateOf("") }
    var adminCode by remember { mutableStateOf("") } // Секретный код для админа

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF5F7FF))
    ) {
        // ШАПКА
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Кнопка назад
            IconButton(onClick = onBackToMain) {
                Icon(
                    imageVector = Icons.Default.ArrowBack,
                    contentDescription = "Назад",
                    tint = Color(0xFF6A5AE0)
                )
            }

            Text(
                text = "Регистрация администратора",
                style = MaterialTheme.typography.headlineSmall,
                color = Color(0xFF6A5AE0)
            )

            Spacer(modifier = Modifier.size(48.dp))
        }

        // ОСНОВНОЙ КОНТЕНТ
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp),
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            // ЗАГОЛОВОК АДМИНА
            Text(
                text = "⚙️ Регистрация администратора",
                style = MaterialTheme.typography.headlineLarge,
                color = Color(0xFF6A5AE0),
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth()
            )

            Text(
                text = "Доступ только для авторизованного персонала",
                style = MaterialTheme.typography.bodyLarge,
                color = Color.Gray,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(16.dp))

            // КАРТОЧКА С ФОРМОЙ АДМИНА
            Card(
                modifier = Modifier.fillMaxWidth(),
                elevation = CardDefaults.cardElevation(6.dp)
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    // Имя администратора
                    OutlinedTextField(
                        value = adminName,
                        onValueChange = { adminName = it },
                        label = { Text("ФИО администратора") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = TextFieldDefaults.colors(
                            focusedIndicatorColor = Color(0xFF6A5AE0),
                            unfocusedIndicatorColor = Color(0xFF6A5AE0).copy(alpha = 0.5f)
                        )
                    )

                    // Email
                    OutlinedTextField(
                        value = adminEmail,
                        onValueChange = { adminEmail = it },
                        label = { Text("Служебный email") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = TextFieldDefaults.colors(
                            focusedIndicatorColor = Color(0xFF6A5AE0),
                            unfocusedIndicatorColor = Color(0xFF6A5AE0).copy(alpha = 0.5f)
                        )
                    )

                    // Пароль
                    OutlinedTextField(
                        value = adminPassword,
                        onValueChange = { adminPassword = it },
                        label = { Text("Пароль") },
                        modifier = Modifier.fillMaxWidth(),
                        visualTransformation = PasswordVisualTransformation(),
                        colors = TextFieldDefaults.colors(
                            focusedIndicatorColor = Color(0xFF6A5AE0),
                            unfocusedIndicatorColor = Color(0xFF6A5AE0).copy(alpha = 0.5f)
                        )
                    )

                    // Секретный код доступа
                    OutlinedTextField(
                        value = adminCode,
                        onValueChange = { adminCode = it },
                        label = { Text("Секретный код доступа") },
                        placeholder = { Text("Только для IT-отдела") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = TextFieldDefaults.colors(
                            focusedIndicatorColor = Color.Red,
                            unfocusedIndicatorColor = Color.Red.copy(alpha = 0.5f)
                        )
                    )

                    // ПОДСКАЗКА ДЛЯ ТЕСТА
                    Text(
                        text = "Для теста используйте код: 1234",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.Gray,
                        fontStyle = FontStyle.Italic
                    )

                    // КНОПКА РЕГИСТРАЦИИ АДМИНА
                    Button(
                        onClick = {
                            if (adminName.isNotEmpty() && adminEmail.isNotEmpty() &&
                                adminPassword.isNotEmpty() && adminCode == "1234"
                            ) {
                                // Успешная регистрация админа
                                onAdminRegistered()
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFF6A5AE0)
                        ),
                        enabled = adminName.isNotEmpty() && adminEmail.isNotEmpty() &&
                                adminPassword.isNotEmpty() && adminCode == "1234"
                    ) {
                        Text("🔐 Зарегистрировать администратора", color = Color.White)
                    }
                }
            }

            // ИНФОРМАЦИЯ ДЛЯ АДМИНА
            Card(
                modifier = Modifier.fillMaxWidth(),
                elevation = CardDefaults.cardElevation(2.dp),
                colors = CardDefaults.cardColors(
                    containerColor = Color(0xFFFFF8E1)
                )
            ) {
                Column(
                    modifier = Modifier.padding(16.dp)
                ) {
                    Text(
                        text = "⚠️ Внимание!",
                        style = MaterialTheme.typography.bodyMedium,
                        color = Color(0xFFE65100),
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Администратор имеет полный доступ ко всем функциям приложения, включая управление пользователями и настройки системы.",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color(0xFFE65100)
                    )
                }
            }
        }
    }
}

@Composable
fun TeacherChatListScreen(
    onBackToMain: () -> Unit,
    onOpenChat: (studentId: Int, studentName: String) -> Unit,
    onMenuClick: () -> Unit
) {
    // Тестовые данные чатов
    val chats = remember {
        listOf(
            Chat(
                chatId = "1",
                studentId = 1,
                studentName = "Анна Иванова",
                lastMessage = "Здравствуйте, у меня вопрос по тесту",
                lastMessageTime = System.currentTimeMillis() - 1000 * 60 * 5, // 5 минут назад
                unreadCount = 2
            ),
            Chat(
                chatId = "2",
                studentId = 3,
                studentName = "София Сидорова",
                lastMessage = "Спасибо за консультацию!",
                lastMessageTime = System.currentTimeMillis() - 1000 * 60 * 60 * 2, // 2 часа назад
                unreadCount = 0
            ),
            Chat(
                chatId = "3",
                studentId = 5,
                studentName = "Елена Смирнова",
                lastMessage = "Можно записаться на встречу?",
                lastMessageTime = System.currentTimeMillis() - 1000 * 60 * 60 * 24, // 1 день назад
                unreadCount = 1
            )
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF5F7FF))
    ) {
        // ШАПКА
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onMenuClick) {
                Icon(Icons.Default.Menu, "Меню", tint = Color(0xFF6A5AE0))
            }

            Text(
                text = "Мои чаты",
                style = MaterialTheme.typography.headlineSmall,
                color = Color(0xFF6A5AE0)
            )

            IconButton(onClick = onBackToMain) {
                Icon(Icons.Default.ArrowBack, "Назад", tint = Color(0xFF6A5AE0))
            }
        }

        // СПИСОК ЧАТОВ
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(chats) { chat ->
                ChatListItem(
                    chat = chat,
                    onClick = { onOpenChat(chat.studentId, chat.studentName) }
                )
            }
        }
    }
}

@Composable
fun ChatListItem(chat: Chat, onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() },
        elevation = CardDefaults.cardElevation(2.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // АВАТАР СТУДЕНТА
            Box(
                modifier = Modifier
                    .size(50.dp)
                    .background(Color(0xFF6A5AE0), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = chat.studentName.split(" ").map { it.first() }.joinToString(""),
                    color = Color.White,
                    fontWeight = FontWeight.Bold
                )
            }

            // ИНФОРМАЦИЯ О ЧАТЕ
            Column(
                modifier = Modifier
                    .weight(1f)
                    .padding(horizontal = 12.dp)
            ) {
                Text(
                    text = chat.studentName,
                    style = MaterialTheme.typography.bodyLarge,
                    fontWeight = FontWeight.Bold
                )

                Text(
                    text = chat.lastMessage,
                    style = MaterialTheme.typography.bodyMedium,
                    color = Color.Gray,
                    maxLines = 1
                )

                Text(
                    text = formatTime(chat.lastMessageTime),
                    style = MaterialTheme.typography.bodySmall,
                    color = Color.Gray
                )
            }

            // СЧЕТЧИК НЕПРОЧИТАННЫХ
            if (chat.unreadCount > 0) {
                Box(
                    modifier = Modifier
                        .size(24.dp)
                        .background(Color.Red, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = chat.unreadCount.toString(),
                        color = Color.White,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

// Функция для форматирования времени
fun formatTime(timestamp: Long): String {
    val now = System.currentTimeMillis()
    val diff = now - timestamp

    return when {
        diff < 60 * 1000 -> "только что"
        diff < 60 * 60 * 1000 -> "${diff / (60 * 1000)} мин назад"
        diff < 24 * 60 * 60 * 1000 -> "${diff / (60 * 60 * 1000)} ч назад"
        else -> "${diff / (24 * 60 * 60 * 1000)} дн назад"
    }
}
@Composable
fun ChatScreen(
    studentId: Int,
    studentName: String,
    onBack: () -> Unit,
    onMenuClick: () -> Unit
) {
    var messageText by remember { mutableStateOf("") }
    val messages = remember {
        mutableStateListOf(
            ChatMessage(
                id = "1",
                senderId = studentId,
                receiverId = 1, // ID учителя
                senderName = studentName,
                message = "Здравствуйте! У меня вопрос по тесту",
                timestamp = System.currentTimeMillis() - 1000 * 60 * 10,
                isRead = true
            ),
            ChatMessage(
                id = "2",
                senderId = 1, // ID учителя
                receiverId = studentId,
                senderName = "Учитель",
                message = "Привет! Конечно, задавай свой вопрос",
                timestamp = System.currentTimeMillis() - 1000 * 60 * 5,
                isRead = true
            )
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF5F7FF))
    ) {
        // ШАПКА ЧАТА
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.Default.ArrowBack, "Назад", tint = Color(0xFF6A5AE0))
            }

            Text(
                text = studentName,
                style = MaterialTheme.typography.headlineSmall,
                color = Color(0xFF6A5AE0),
                modifier = Modifier.weight(1f)
            )

            IconButton(onClick = onMenuClick) {
                Icon(Icons.Default.Menu, "Меню", tint = Color(0xFF6A5AE0))
            }
        }

        // СПИСОК СООБЩЕНИЙ
        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .padding(horizontal = 16.dp),
            reverseLayout = true,
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(messages.reversed()) { message ->
                MessageBubble(message = message, isTeacher = message.senderId == 1)
            }
        }

        // ПОЛЕ ВВОДА СООБЩЕНИЯ
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = messageText,
                onValueChange = { messageText = it },
                placeholder = { Text("Введите сообщение...") },
                modifier = Modifier.weight(1f),
                colors = TextFieldDefaults.colors(
                    focusedIndicatorColor = Color(0xFF6A5AE0),
                    unfocusedIndicatorColor = Color(0xFF6A5AE0).copy(alpha = 0.5f)
                )
            )

            Button(
                onClick = {
                    if (messageText.isNotBlank()) {
                        val newMessage = ChatMessage(
                            id = (messages.size + 1).toString(),
                            senderId = 1,
                            receiverId = studentId,
                            senderName = "Учитель",
                            message = messageText,
                            timestamp = System.currentTimeMillis(),
                            isRead = true
                        )
                        messages.add(newMessage)
                        messageText = ""
                    }
                },
                enabled = messageText.isNotBlank(),
                modifier = Modifier.padding(start = 8.dp)
            ) {
                Text("Отпр.")
            }
        }
    }
}

@Composable
fun MessageBubble(message: ChatMessage, isTeacher: Boolean) {
    val horizontalAlignment = if (isTeacher) Alignment.End else Alignment.Start
    val backgroundColor = if (isTeacher) Color(0xFF6A5AE0) else Color(0xFFE8E6FF)

    // ИСПРАВЛЕННЫЙ Box - используем fillMaxWidth и отдельно выравнивание
    Box(
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .wrapContentWidth()
                .align(if (isTeacher) Alignment.TopEnd else Alignment.TopStart),
            horizontalAlignment = horizontalAlignment
        ) {
            if (!isTeacher) {
                Text(
                    text = message.senderName,
                    style = MaterialTheme.typography.bodySmall,
                    color = Color.Gray
                )
            }

            Card(
                modifier = Modifier.padding(vertical = 4.dp),
                colors = CardDefaults.cardColors(containerColor = backgroundColor),
                elevation = CardDefaults.cardElevation(2.dp)
            ) {
                Text(
                    text = message.message,
                    modifier = Modifier.padding(12.dp),
                    color = if (isTeacher) Color.White else Color.Black
                )
            }

            Text(
                text = formatTime(message.timestamp),
                style = MaterialTheme.typography.bodySmall,
                color = Color.Gray
            )
        }
    }
}
/*
// ==================== БАЗА ДАННЫХ (УПРОЩЕННАЯ) ====================
//@Entity(tableName = "users")
//data class UserEntity(
   // @PrimaryKey val id: Int,
   // @ColumnInfo(name = "first_name") val firstName: String,
   // @ColumnInfo(name = "last_name") val lastName: String,
   // @ColumnInfo(name = "role") val role: Int
//)

//@Dao
//interface UserDao {
   // @Query("SELECT * FROM users WHERE role = 0")
    //fun getStudents(): List<UserEntity>

   // @Insert
    //fun insertUser(user: UserEntity)
//}

//@Database(
    //entities = [UserEntity::class],
    //version = 1,
    //exportSchema = false
//)
//abstract class PsychologyDatabase : RoomDatabase() {
    //abstract fun userDao(): UserDao

   // companion object {
    //    @Volatile
     //   private var INSTANCE: PsychologyDatabase? = null

      //  fun getInstance(context: Context): PsychologyDatabase {
         //   return INSTANCE ?: synchronized(this) {
         //       val instance = Room.databaseBuilder(
          //          context.applicationContext,
          //          PsychologyDatabase::class.java,
          //          "psychology_db"
          //      ).build()
          //      INSTANCE = instance
           //     instance
          //  }
       // }
   // }
//}

// ПРОСТОЙ РЕПОЗИТОРИЙ
//class AppRepository(private val context: Context) {
    //private val database = PsychologyDatabase.getInstance(context)

   // fun getStudents(): List<UserEntity> {
      //  return try {
           // database.userDao().getStudents()
       // } catch (e: Exception) {
           // emptyList() // если ошибка - возвращаем пустой список
      //  }
  //  }

    //fun addUser(user: UserEntity) {
      //  try {
      //      database.userDao().insertUser(user)
      //  } catch (e: Exception) {
            // игнорируем ошибки при добавлении
      //  }
  //  }
//}
/*
fun getTestStudents(): List<Student> {
    return listOf(
        Student(1, "Анна", "Иванова", 28, "Сегодня", true),
        Student(2, "Максим", "Петров", 32, "Вчера", false),
        Student(3, "София", "Сидорова", null, "2 дня назад", true),
        Student(4, "Дмитрий", "Кузнецов", 19, "Неделю назад", false),
        Student(5, "Елена", "Смирнова", 35, "Сегодня", false)
    )
}*/*/
// ==================== ЭКРАН ПЕРСОНАЛЬНЫХ РЕКОМЕНДАЦИЙ ====================

@Composable
fun PersonalAdviceScreen(
    userName: String,
    userScore: Int,
    onStartChat: () -> Unit,
    onBackToMain: () -> Unit,
    onViewHistory: () -> Unit // ← ДОБАВЛЯЕМ НОВЫЙ КОЛБЭК
) {
    val showWarning = userScore <= 15 // Предупреждение для низких баллов

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp)
            .background(Color(0xFFF5F7FF)),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // КАРТОЧКА С ДАННЫМИ ПОЛЬЗОВАТЕЛЯ (ПО ЦЕНТРУ)
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 20.dp),
            elevation = CardDefaults.cardElevation(8.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White)
        ) {
            Column(
                modifier = Modifier.padding(32.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // АВАТАР ПОЛЬЗОВАТЕЛЯ
                Box(
                    modifier = Modifier
                        .size(80.dp)
                        .background(Color(0xFF6A5AE0), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = userName.split(" ").map { it.first() }.joinToString(""),
                        color = Color.White,
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Spacer(modifier = Modifier.height(24.dp))

                // ИМЯ И ФАМИЛИЯ ПО ЦЕНТРУ
                Text(
                    text = userName,
                    style = MaterialTheme.typography.headlineMedium,
                    color = Color(0xFF6A5AE0),
                    textAlign = TextAlign.Center,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(16.dp))

                // РЕЗУЛЬТАТ ТЕСТА
                Text(
                    text = "Результат теста: $userScore/40 баллов",
                    style = MaterialTheme.typography.bodyLarge,
                    color = Color.Gray,
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(8.dp))

                // СТАТУС РЕЗУЛЬТАТА
                val (statusText, statusColor) = when {
                    userScore <= 15 -> "Требуется внимание" to Color(0xFFE53935)
                    userScore <= 25 -> "Стабильное состояние" to Color(0xFFFB8C00)
                    else -> "Отличный результат" to Color(0xFF43A047)
                }

                Text(
                    text = statusText,
                    style = MaterialTheme.typography.bodyMedium,
                    color = statusColor,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        Spacer(modifier = Modifier.height(32.dp))

        // ПРЕДУПРЕЖДЕНИЕ ДЛЯ ВЫСОКОГО РИСКА
        if (showWarning) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                elevation = CardDefaults.cardElevation(4.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF8E1))
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "⚠️",
                        style = MaterialTheme.typography.headlineSmall,
                        modifier = Modifier.padding(end = 12.dp)
                    )
                    Text(
                        text = "Рекомендуем обратиться к школьному психологу для консультации",
                        style = MaterialTheme.typography.bodyMedium,
                        color = Color(0xFFE65100)
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))
        }

        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Button(
                onClick = onStartChat,
                modifier = Modifier.fillMaxWidth().height(60.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF6A5AE0))
            ) {
                Text("💬 Начать общение с психологом")
            }

            // НОВАЯ КНОПКА - ИСТОРИЯ ТЕСТОВ
            Button(
                onClick = onViewHistory, // ← ИСПОЛЬЗУЕМ КОЛБЭК
                modifier = Modifier.fillMaxWidth().height(50.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF4CAF50))
            ) {
                Text("📊 Моя история тестов")
            }

            Button(
                onClick = onBackToMain,
                modifier = Modifier.fillMaxWidth().height(50.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color.LightGray)
            ) {
                Text("Вернуться на главную", color = Color.Black)
            }

        }

        // ДОПОЛНИТЕЛЬНАЯ ИНФОРМАЦИЯ
        Spacer(modifier = Modifier.height(32.dp))

        Text(
            text = "Ваши данные сохранены анонимно",
            style = MaterialTheme.typography.bodySmall,
            color = Color.Gray.copy(alpha = 0.6f)
        )
    }
}
// ФУНКЦИЯ ДЛЯ ОПРЕДЕЛЕНИЯ РЕКОМЕНДАЦИЙ
fun getAdviceBasedOnScore(score: Int): String {
    return when {
        score <= 15 -> "На основе ваших результатов рекомендуется срочно обратиться к профессиональному психологу для консультации. Не откладывайте заботу о своем психическом здоровье."
        score <= 25 -> "Ваши результаты указывают на некоторые эмоциональные трудности. Рекомендуется регулярно практиковать техники релаксации и рассмотреть возможность консультации со специалистом."
        score <= 35 -> "Ваше эмоциональное состояние в целом стабильно. Продолжайте практиковать здоровые привычки и саморефлексию для поддержания баланса."
        else -> "Отличные результаты! Вы демонстрируете высокий уровень эмоционального благополучия. Продолжайте в том же духе и делитесь своими стратегиями с другими."
    }
}
// Добавим эту функцию в основной код
@Composable
fun StudentChatListScreen(
    onBackToMain: () -> Unit,
    onOpenChat: (teacherId: Int, teacherName: String) -> Unit,
    onMenuClick: () -> Unit
) {
    // Список доступных учителей/психологов
    val teachers = remember {
        listOf(
            Chat(
                chatId = "teacher_1",
                studentId = 1,
                studentName = "Мария Ивановна",
                lastMessage = "Школьный психолог",
                lastMessageTime = System.currentTimeMillis(),
                unreadCount = 0
            ),
            Chat(
                chatId = "teacher_2",
                studentId = 2,
                studentName = "Анна Петровна",
                lastMessage = "Классный руководитель",
                lastMessageTime = System.currentTimeMillis() - 1000 * 60 * 60,
                unreadCount = 1
            )
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF5F7FF))
    ) {
        // ШАПКА
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onMenuClick) {
                Icon(Icons.Default.Menu, "Меню", tint = Color(0xFF6A5AE0))
            }

            Text(
                text = "Выберите собеседника",
                style = MaterialTheme.typography.headlineSmall,
                color = Color(0xFF6A5AE0)
            )

            IconButton(onClick = onBackToMain) {
                Icon(Icons.Default.ArrowBack, "Назад", tint = Color(0xFF6A5AE0))
            }
        }

        // СПИСОК ДОСТУПНЫХ УЧИТЕЛЕЙ
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(teachers) { teacher ->
                TeacherChatListItem(
                    teacher = teacher,
                    onClick = { onOpenChat(teacher.studentId, teacher.studentName) }
                )
            }
        }
    }
}

@Composable
fun TeacherChatListItem(teacher: Chat, onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() },
        elevation = CardDefaults.cardElevation(2.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // АВАТАР УЧИТЕЛЯ
            Box(
                modifier = Modifier
                    .size(50.dp)
                    .background(Color(0xFF4CAF50), CircleShape), // Зеленый для учителей
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "👨‍🏫",
                    fontSize = 20.sp
                )
            }

            // ИНФОРМАЦИЯ ОБ УЧИТЕЛЕ
            Column(
                modifier = Modifier
                    .weight(1f)
                    .padding(horizontal = 12.dp)
            ) {
                Text(
                    text = teacher.studentName, // Здесь имя учителя
                    style = MaterialTheme.typography.bodyLarge,
                    fontWeight = FontWeight.Bold
                )

                Text(
                    text = teacher.lastMessage, // Должность/специализация
                    style = MaterialTheme.typography.bodyMedium,
                    color = Color.Gray
                )
            }

            // СЧЕТЧИК НЕПРОЧИТАННЫХ
            if (teacher.unreadCount > 0) {
                Box(
                    modifier = Modifier
                        .size(24.dp)
                        .background(Color.Red, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = teacher.unreadCount.toString(),
                        color = Color.White,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}
@Composable
fun StudentChatScreen(
    teacherId: Int,
    teacherName: String,
    onBack: () -> Unit,
    onMenuClick: () -> Unit,
    onRetakeTest: () -> Unit  // ← ДОБАВЛЯЕМ НОВЫЙ КОЛБЭК
) {
    var messageText by remember { mutableStateOf("") }
    val messages = remember {
        mutableStateListOf(
            ChatMessage(
                id = "1",
                senderId = teacherId,
                receiverId = 0,
                senderName = teacherName,
                message = "Здравствуйте! Чем могу помочь?",
                timestamp = System.currentTimeMillis() - 1000 * 60 * 5,
                isRead = true
            )
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF5F7FF))
    ) {
        // ШАПКА ЧАТА С КНОПКОЙ "ПРОЙТИ ТЕСТ ЗАНОВО"
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.Default.ArrowBack, "Назад", tint = Color(0xFF6A5AE0))
            }

            // АВАТАР УЧИТЕЛЯ
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .background(Color(0xFF4CAF50), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Text("👨‍🏫", fontSize = 16.sp)
            }

            Text(
                text = teacherName,
                style = MaterialTheme.typography.headlineSmall,
                color = Color(0xFF6A5AE0),
                modifier = Modifier
                    .weight(1f)
                    .padding(start = 12.dp)
            )

            // КНОПКА "ПРОЙТИ ТЕСТ ЗАНОВО" - В ПРАВОМ ВЕРХНЕМ УГЛУ
            IconButton(
                onClick = onRetakeTest,
                modifier = Modifier
                    .size(48.dp)
                    .background(Color(0xFFFF9800), CircleShape)
            ) {
                Text(
                    text = "📊",
                    fontSize = 18.sp
                )
            }

            IconButton(onClick = onMenuClick) {
                Icon(Icons.Default.Menu, "Меню", tint = Color(0xFF6A5AE0))
            }
        }

        // БАННЕР С ПОДСКАЗКОЙ О ТЕСТЕ (опционально)
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFFE3F2FD)),
            elevation = CardDefaults.cardElevation(2.dp)
        ) {
            Row(
                modifier = Modifier.padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "💡",
                    modifier = Modifier.padding(end = 8.dp)
                )
                Text(
                    text = "Можете пройти тест заново, чтобы обсудить изменения",
                    style = MaterialTheme.typography.bodySmall,
                    color = Color(0xFF1976D2)
                )
            }
        }

        // СПИСОК СООБЩЕНИЙ (без изменений)
        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .padding(horizontal = 16.dp),
            reverseLayout = true,
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(messages.reversed()) { message ->
                MessageBubble(
                    message = message,
                    isTeacher = message.senderId == teacherId
                )
            }
        }

        // ПОЛЕ ВВОДА СООБЩЕНИЯ (без изменений)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = messageText,
                onValueChange = { messageText = it },
                placeholder = { Text("Напишите сообщение...") },
                modifier = Modifier.weight(1f),
                colors = TextFieldDefaults.colors(
                    focusedIndicatorColor = Color(0xFF6A5AE0),
                    unfocusedIndicatorColor = Color(0xFF6A5AE0).copy(alpha = 0.5f)
                )
            )

            Button(
                onClick = {
                    if (messageText.isNotBlank()) {
                        val newMessage = ChatMessage(
                            id = (messages.size + 1).toString(),
                            senderId = 0,
                            receiverId = teacherId,
                            senderName = "Ученик",
                            message = messageText,
                            timestamp = System.currentTimeMillis(),
                            isRead = true
                        )
                        messages.add(newMessage)
                        messageText = ""
                    }
                },
                enabled = messageText.isNotBlank(),
                modifier = Modifier.padding(start = 8.dp)
            ) {
                Text("Отпр.")
            }
        }
    }
}
@Composable
fun StudentTestHistoryScreen(
    studentName: String,
    testHistory: List<TestResult>,
    onBack: () -> Unit,
    onMenuClick: () -> Unit
) {
    // ДЛЯ ОТЛАДКИ: выведем размер истории
    LaunchedEffect(testHistory) {
        println("🎯 StudentTestHistoryScreen получил историю: ${testHistory.size} тестов")
        testHistory.forEachIndexed { index, test ->
            println("   Тест $index: ${test.score} баллов, ${test.date}")
        }
    }
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF5F7FF))
    ) {
        // ШАПКА
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.Default.ArrowBack, "Назад", tint = Color(0xFF6A5AE0))
            }

            Text(
                text = "История тестов",
                style = MaterialTheme.typography.headlineSmall,
                color = Color(0xFF6A5AE0)
            )

            IconButton(onClick = onMenuClick) {
                Icon(Icons.Default.Menu, "Меню", tint = Color(0xFF6A5AE0))
            }
        }

        if (testHistory.isEmpty()) {
            // ЕСЛИ ИСТОРИИ НЕТ
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Text(
                    text = "📊",
                    fontSize = 64.sp,
                    modifier = Modifier.padding(bottom = 16.dp)
                )
                Text(
                    text = "История тестов пуста",
                    style = MaterialTheme.typography.headlineSmall,
                    textAlign = TextAlign.Center
                )
                Text(
                    text = "Пройдите психологический тест, чтобы увидеть здесь результаты",
                    style = MaterialTheme.typography.bodyMedium,
                    color = Color.Gray,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(top = 8.dp)
                )
            }
        } else {
            // ГРАФИК ПРОГРЕССА (простая версия)
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                elevation = CardDefaults.cardElevation(4.dp)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp)
                ) {
                    Text(
                        text = "📈 Динамика результатов",
                        style = MaterialTheme.typography.bodyLarge,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(16.dp))

                    // ПРОСТОЙ ГРАФИК ИЗ ТЕКСТА
                    testHistory.sortedBy { it.id }.forEachIndexed { index, result ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Тест ${index + 1}:")
                            Text("${result.score}/40 баллов",
                                fontWeight = FontWeight.Bold,
                                color = when {
                                    result.score <= 15 -> Color(0xFFE53935)
                                    result.score <= 25 -> Color(0xFFFB8C00)
                                    else -> Color(0xFF43A047)
                                }
                            )
                        }
                    }
                }
            }

            // СПИСОК ТЕСТОВ
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(testHistory.sortedByDescending { it.id }) { testResult ->
                    TestHistoryItem(testResult = testResult)
                }
            }
        }
    }
}

@Composable
fun TestHistoryItem(testResult: TestResult) {
    Card(
        modifier = Modifier
            .fillMaxWidth(),
        elevation = CardDefaults.cardElevation(2.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Тест от ${testResult.date}",
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Bold
                )

                // БАЛЛ С ЦВЕТОМ
                Text(
                    text = "${testResult.score}/40",
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold,
                    color = when {
                        testResult.score <= 15 -> Color(0xFFE53935)
                        testResult.score <= 25 -> Color(0xFFFB8C00)
                        else -> Color(0xFF43A047)
                    }
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            // СТАТУС
            val statusText = when {
                testResult.score <= 15 -> "Требуется внимание"
                testResult.score <= 25 -> "Стабильное состояние"
                else -> "Отличный результат"
            }

            Text(
                text = statusText,
                style = MaterialTheme.typography.bodyMedium,
                color = when {
                    testResult.score <= 15 -> Color(0xFFE53935)
                    testResult.score <= 25 -> Color(0xFFFB8C00)
                    else -> Color(0xFF43A047)
                }
            )

            Spacer(modifier = Modifier.height(8.dp))

            // РЕКОМЕНДАЦИИ (сокращенные)
            Text(
                text = testResult.recommendations.take(100) + "...",
                style = MaterialTheme.typography.bodySmall,
                color = Color.Gray
            )
        }
    }
}
fun getCurrentDateTime(): String {
    val dateFormat = java.text.SimpleDateFormat("dd.MM.yyyy HH:mm", java.util.Locale.getDefault())
    return dateFormat.format(java.util.Date())
}