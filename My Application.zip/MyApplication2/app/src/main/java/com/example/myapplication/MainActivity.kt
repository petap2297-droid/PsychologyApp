package com.example.myapplication

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            // Это тема приложения - просто оставьте так
            MaterialTheme {
                // Показываем наш экран регистрации
                RegistrationScreen()
            }
        }
    }
}

// ЭКРАН РЕГИСТРАЦИИ
@Composable
fun RegistrationScreen() {
    // Эти переменные хранят то, что введет пользователь
    var firstName by remember { mutableStateOf("") }
    var lastName by remember { mutableStateOf("") }
    var isStudent by remember { mutableStateOf(true) }

    // Это layout - как будут расположены элементы
    Column(
        modifier = Modifier
            .fillMaxSize()          // занимает весь экран
            .padding(24.dp),        // отступы от краев
        verticalArrangement = Arrangement.Center,  // выравнивание по центру
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // ЗАГОЛОВОК
        Text(
            text = "Добро пожаловать!",
            style = MaterialTheme.typography.headlineMedium
        )

        Spacer(modifier = Modifier.height(16.dp))

        Text(
            text = "Зарегистрируйтесь для начала работы",
            style = MaterialTheme.typography.bodyMedium
        )

        Spacer(modifier = Modifier.height(32.dp))

// ПОЛЕ ДЛЯ ИМЕНИ
        TextField(
            value = firstName,
            onValueChange = { firstName = it },
            label = { Text("Ваше имя") },
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(16.dp))

// ПОЛЕ ДЛЯ ФАМИЛИИ
        TextField(
            value = lastName,
            onValueChange = { lastName = it },
            label = { Text("Ваша фамилия") },
            modifier = Modifier.fillMaxWidth()
        )
        // ВЫБОР РОЛИ
        Text("Выберите роль:")

        Spacer(modifier = Modifier.height(8.dp))

        Row {
            // КНОПКА "УЧЕНИК"
            Row(verticalAlignment = Alignment.CenterVertically) {
                RadioButton(
                    selected = isStudent,
                    onClick = { isStudent = true }
                )
                Text("Ученик")
            }

            Spacer(modifier = Modifier.width(20.dp))

            // КНОПКА "УЧИТЕЛЬ"
            Row(verticalAlignment = Alignment.CenterVertically) {
                RadioButton(
                    selected = !isStudent,
                    onClick = { isStudent = false }
                )
                Text("Учитель")
            }
        }

        Spacer(modifier = Modifier.height(32.dp))

        // КНОПКА РЕГИСТРАЦИИ
        Button(
            onClick = {
                // Проверяем заполнены ли поля
                if (firstName.isNotEmpty() && lastName.isNotEmpty()) {
                    // Пока просто покажем сообщение
                    val role = if (isStudent) "ученик" else "учитель"
                    // TODO: позже сделаем переход на тест
                }
            },
            modifier = Modifier
                .fillMaxWidth()
                .height(50.dp)
        ) {
            Text("Продолжить")
        }
    }
}