package com.example.myapplication.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.asLiveData
import com.example.myapplication.data.UserRepository
import com.example.myapplication.data.User
import kotlinx.coroutines.launch

class UserViewModel(private val userRepository: UserRepository) : ViewModel() {

    // РЕГИСТРАЦИЯ нового пользователя
    fun registerUser(username: String, role: String) {
        viewModelScope.launch {
            val userId = userRepository.createUser(username, role)
            // Сохраняем ID пользователя в DataStore (для автовхода)
            saveUserIdToPreferences(userId)
        }
    }

    // ПОЛУЧЕНИЕ текущего пользователя (для отображения)
    fun getCurrentUser(userId: String) =
        userRepository.getCurrentUserFlow(userId).asLiveData()

    // ПОЛУЧЕНИЕ всех учеников (для админ-панели)
    fun getStudents() = userRepository.getStudents().asLiveData()

    // ПОЛУЧЕНИЕ всех учителей (для чата)
    fun getTeachers() = userRepository.getTeachers().asLiveData()

    // ПРОВЕРКА доступности имени пользователя
    suspend fun checkUsernameAvailability(username: String): Boolean {
        return userRepository.isUsernameAvailable(username)
    }

    // СОХРАНЕНИЕ ID пользователя в DataStore (у тебя уже есть DataStore)
    private suspend fun saveUserIdToPreferences(userId: String) {
        // Здесь используй твой существующий DataStore код
        // Например: preferencesDataStore.edit { it[USER_ID_KEY] = userId }
    }

    // ПОЛУЧЕНИЕ ID пользователя из DataStore
    suspend fun getUserIdFromPreferences(): String? {
        // Верни сохранённый ID или null
        return null // Замени на реальный код
    }
}