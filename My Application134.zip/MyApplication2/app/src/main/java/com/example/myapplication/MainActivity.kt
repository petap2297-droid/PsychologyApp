package com.example.myapplication

import android.os.Bundle // ОСНОВНЫЕ ANDROID КОМПОНЕНТЫ
import androidx.activity.ComponentActivity //базовая активность Android
import androidx.activity.compose.setContent //позволяет использовать Compose вместо XML разметки
import androidx.compose.foundation.layout.* //контейнеры, модификаторы размеров,выравнивание
import androidx.compose.material3.*// Button, TextField, Card - кнопки, поля ввода, карточки MaterialTheme - система тем ext, Icon - текст и иконки
import androidx.compose.runtime.* //mutableStateOf()-создание реактивных переменных remember-сохранение состояния между перерисовками LaunchedEffect-запуск побочных эффектов (аналог lifecycle)
import androidx.compose.ui.Alignment//Alignment - выравнивание внутри контейнеров
import androidx.compose.ui.Modifier//цепочка модификаторов внешнего вида
import androidx.compose.ui.unit.dp// единицы измерения (пиксели и scale-independent pixels)
import androidx.compose.foundation.clickable//делает любой элемент кликабельным
import androidx.compose.ui.graphics.Color// работа с цветами
import androidx.compose.ui.text.font.FontWeight //жирность текста
import androidx.compose.ui.text.style.TextAlign//выравнивание текста (Center)
import androidx.compose.foundation.background// фон элементов
import androidx.compose.ui.platform.LocalContext//Доступ к контексту Android (для Toast, ресурсов и тд)
import androidx.compose.ui.unit.sp//единицы измерения (пиксели и scale-independent pixels)
import androidx.compose.foundation.lazy.LazyColumn//оптимизированный список (подгружает только видимые элементы)
import androidx.compose.foundation.lazy.items//рендеринг элементов списка
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.material.icons.Icons// набор готовых иконок Material Design
import androidx.compose.material3.IconButton//кнопка с иконкой
import androidx.compose.material3.Icon //отображение иконки
import androidx.compose.material3.darkColorScheme// Готовые цветовые схемы для светлой и темной тем
import androidx.compose.material3.lightColorScheme// Готовые цветовые схемы для светлой и темной тем
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.BorderStroke//границы элементов
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.ModalNavigationDrawer//контейнер меню
import androidx.compose.material3.ModalDrawerSheet//содержимое меню
import androidx.compose.material3.NavigationDrawerItem// пункты меню
import androidx.compose.material3.Divider
import androidx.compose.material3.DrawerValue// состояние меню (открыто/закрыто)
import androidx.compose.material3.rememberDrawerState
import kotlinx.coroutines.launch//launch - запуск асинхронных операций
import androidx.compose.runtime.rememberCoroutineScope//область видимости для корутин в Compose
import androidx.compose.ui.text.font.FontStyle //fontStyle - стиль текста
import androidx.compose.ui.text.input.PasswordVisualTransformation//скрытие пароля (звездочки)


// ДАННЫЕ ДЛЯ УПРАВЛЕНИЯ ТЕМОЙ
enum class ColorTheme { LIGHT, DARK, AUTO }

@Composable
fun rememberAppThemeState() = remember {
    mutableStateOf(ColorTheme.LIGHT)
}
// МОДЕЛЬ ДАННЫХ УЧЕНИКА
data class Student(
    val id: Int, //// Уникальный номер ученика (1, 2, 3...)
    val firstName: String, // Имя
    val lastName: String, //  // Фамилия
    val testScore: Int? = null,  // // Результат теста
    val lastActive: String = "Сегодня", //Когда был в сети
    val hasUnreadMessages: Boolean = false //
)
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                // Показываем главный экран приложения
                PsychologyApp()
            }
        }
    }
}
@Composable
fun MyAppTheme(
    darkTheme: Boolean = false,
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) {
        // УЛУЧШЕННАЯ ТЕМНАЯ ТЕМА
        darkColorScheme(
            primary = Color(0xFFBB86FC),
            onPrimary = Color(0xFF000000),
            primaryContainer = Color(0xFF3700B3),
            onPrimaryContainer = Color(0xFFEADDFF),
            secondary = Color(0xFF03DAC6),
            onSecondary = Color(0xFF000000),
            background = Color(0xFF121212),       // Тёмный фон
            onBackground = Color(0xFFFFFFFF),     // Белый текст на тёмном
            surface = Color(0xFF1E1E1E),          // Тёмные карточки
            onSurface = Color(0xFFFFFFFF),        // Белый текст на карточках
            surfaceVariant = Color(0xFF2D2D2D),
            onSurfaceVariant = Color(0xFFC8C8C8)
        )
    } else {
        // СВЕТЛАЯ ТЕМА
        lightColorScheme(
            primary = Color(0xFF6A5AE0),
            onPrimary = Color(0xFFFFFFFF),
            primaryContainer = Color(0xFFE8E6FF),
            onPrimaryContainer = Color(0xFF1A0061),
            secondary = Color(0xFF625B71),
            onSecondary = Color(0xFFFFFFFF),
            background = Color(0xFFF5F7FF),       // Светлый фон
            onBackground = Color(0xFF1C1B1F),     // Тёмный текст на светлом
            surface = Color(0xFFFFFFFF),          // Белые карточки
            onSurface = Color(0xFF1C1B1F),        // Тёмный текст на карточках
            surfaceVariant = Color(0xFFE7E0EC),
            onSurfaceVariant = Color(0xFF49454F)
        )
    }
    MaterialTheme(
        colorScheme = colorScheme,
        typography = MaterialTheme.typography,
        content = content
    )
}
// Главное приложение, которое управляет экранами

@Composable//эта функция создает UI элементы
fun PsychologyApp() {
    val themeState = rememberAppThemeState()
    var currentScreen by remember { mutableStateOf("registration") }
    var selectedUserRole by remember { mutableStateOf(0) }
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val scope = rememberCoroutineScope()

    // Функции для drawer
    fun openDrawer() {
        scope.launch { drawerState.open() }
    }
    fun closeDrawer() {
        scope.launch { drawerState.close() }
    }

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet {
                // Заголовок меню
                Text(
                    text = "Меню",
                    modifier = Modifier.padding(16.dp),
                    style = MaterialTheme.typography.headlineSmall,
                    color = MaterialTheme.colorScheme.primary
                )

                Divider()

                // Пункт "Сменить роль"
                NavigationDrawerItem(
                    label = { Text("👥 Сменить роль") },
                    selected = false,
                    onClick = {
                        currentScreen = "registration"
                        closeDrawer()
                    }
                )

                // Пункт "Настройки темы"
                NavigationDrawerItem(
                    label = {
                        Text(
                            if (themeState.value == ColorTheme.DARK) "☀️ Светлая тема" else "🌙 Тёмная тема"
                        )
                    },
                    selected = false,
                    onClick = {
                        themeState.value = if (themeState.value == ColorTheme.LIGHT) ColorTheme.DARK else ColorTheme.LIGHT
                        closeDrawer()
                    }
                )

                // Пункт "Панель администратора" - ТЕПЕРЬ ВЕДЕТ НА РЕГИСТРАЦИЮ
                NavigationDrawerItem(
                    label = { Text("⚙️ Панель администратора") },
                    selected = false,
                    onClick = {
                        // ВАЖНО: теперь переходим на экран регистрации админа
                        currentScreen = "admin_registration"
                        closeDrawer()
                    }
                )

                Spacer(modifier = Modifier.weight(1f))

                Text(
                    text = "Психологический помощник v0.4",
                    modifier = Modifier.padding(16.dp),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    ) {
        // ОСНОВНОЕ СОДЕРЖИМОЕ ПРИЛОЖЕНИЯ
        when (currentScreen) {
            "registration" -> RegistrationScreen(
                onStartTest = {
                    when (selectedUserRole) {
                        0 -> currentScreen = "test"
                        1 -> currentScreen = "teacher"
                        2 -> currentScreen = "admin_registration" // админ → регистрация
                        else -> currentScreen = "test"
                    }
                },
                onRoleSelected = { role -> selectedUserRole = role },
                onMenuClick = { openDrawer() }
            )
            "test" -> PsychologyTestScreen(
                onBackToMain = { currentScreen = "registration" },
                onMenuClick = { openDrawer() }
            )
            "teacher" -> TeacherScreen(
                onBackToMain = { currentScreen = "registration" },
                onMenuClick = { openDrawer() }
            )
            "admin_registration" -> AdminRegistrationScreen(  //  НОВЫЙ ЭКРАН
                onBackToMain = { currentScreen = "registration" },
                onAdminRegistered = {
                    // После успешной регистрации переходим в админ-панель
                    currentScreen = "admin"
                }
            )
            "admin" -> AdminScreen(  // ← АДМИН-ПАНЕЛЬ (после регистрации)
                onBackToMain = { currentScreen = "registration" },
                onMenuClick = { openDrawer() }
            )
        }
    }
}
// ЭКРАН РЕГИСТРАЦИИ
@Composable//эта функция создает UI элементы
fun RegistrationScreen(
 //Колбэк-функция (функция обратного вызова) — функция, предназначенная для отложенного выполнения. Проще говоря, она должна быть выполнена после завершения работы другой функции.
    onStartTest: () -> Unit,//функция-колбэк, которая вызывается при начале теста
    onRoleSelected: (Int) -> Unit = {},// колбэк при выборе роли (получает номер роли)
    onMenuClick: () -> Unit// колбэк при нажатии на меню
) {
    //remember - запоминает значение между перерисовками
    var firstName by remember { mutableStateOf("") }//переменная для имени
    var lastName by remember { mutableStateOf("") }//создает переменную:
    var selectedRole by remember { mutableStateOf(0) }//
    val context = LocalContext.current//Получает доступ к контексту Android

    LaunchedEffect(selectedRole) { // запускает код когда меняется selectedRole
        onRoleSelected(selectedRole)// сообщает о вырабнной роли
    }

    Column(//контейнер
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF5F7FF)) // ← ПРОСТОЙ ФОН
    ) {
        // ШАПКА С КНОПКОЙ МЕНЮ
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Кнопка меню (три полоски)
            IconButton(onClick = onMenuClick) {
                Icon(
                    imageVector = Icons.Default.Menu,
                    contentDescription = "Меню",
                    tint = Color(0xFF6A5AE0)
                )
            }

            Text(
                text = "Регистрация",
                style = MaterialTheme.typography.headlineSmall,
                color = Color(0xFF6A5AE0)
            )

            // ПУСТОЙ ЭЛЕМЕНТ ДЛЯ ВЫРАВНИВАНИЯ (вместо кнопки темы)
            Spacer(modifier = Modifier.size(48.dp))
        }

        // ОСНОВНОЙ КОНТЕНТ
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp),
            verticalArrangement = Arrangement.Center, // ← ИСПОЛЬЗУЕМ Center вместо weight
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Заголовок
            Text(
                text = "👋 Добро пожаловать!",
                style = MaterialTheme.typography.headlineLarge,
                color = Color(0xFF6A5AE0),
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth()
            )

            Text(
                text = "Психологический помощник",
                style = MaterialTheme.typography.bodyLarge,
                color = Color(0xFF6A5AE0).copy(alpha = 0.8f),
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(32.dp))

            // Карточка с формой
            Card(
                modifier = Modifier.fillMaxWidth(),
                elevation = CardDefaults.cardElevation(4.dp)
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    verticalArrangement = Arrangement.spacedBy(20.dp)
                ) {
                    // Поля ввода
                    OutlinedTextField(
                        value = firstName,
                        onValueChange = { firstName = it },
                        label = { Text("Имя") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = TextFieldDefaults.colors(
                            focusedIndicatorColor = Color(0xFF6A5AE0),
                            unfocusedIndicatorColor = Color(0xFF6A5AE0).copy(alpha = 0.5f)
                        )
                    )

                    OutlinedTextField(
                        value = lastName,
                        onValueChange = { lastName = it },
                        label = { Text("Фамилия") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = TextFieldDefaults.colors(
                            focusedIndicatorColor = Color(0xFF6A5AE0),
                            unfocusedIndicatorColor = Color(0xFF6A5AE0).copy(alpha = 0.5f)
                        )
                    )

                    // Выбор роли
                    Text(
                        text = "Выберите роль:",
                        style = MaterialTheme.typography.bodyMedium
                    )

                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        RoleButton(
                            text = "🎓 Ученик",
                            isSelected = selectedRole == 0,
                            onClick = { selectedRole = 0 }
                        )

                        RoleButton(
                            text = "👨‍🏫 Учитель",
                            isSelected = selectedRole == 1,
                            onClick = { selectedRole = 1 }
                        )
                    }
                    // Кнопка регистрации
                    Button(
                        onClick = {
                            if (firstName.isNotEmpty() && lastName.isNotEmpty()) {
                                onStartTest()
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFF6A5AE0)
                        ),
                        enabled = firstName.isNotEmpty() && lastName.isNotEmpty()
                    ) {
                        Text("Начать тест 🚀", color = Color.White)
                    }
                }
            }
        }
    }
}
@Composable
fun RoleButton(text: String, isSelected: Boolean, onClick: () -> Unit) { //Создаем переиспользуемый компонент кнопки роли
    val backgroundColor = if (isSelected) MaterialTheme.colorScheme.primary.copy(alpha = 0.1f) else Color.Transparent // проверяем выбрана ли кнопка если да то берем основной цвет темы .Если нет полностью прозрачный фон
    val borderColor = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline//Если выбрана: Основной цвет темы . Если не выбрана: MaterialTheme.colorScheme.outline - стандартный цвет границы (серый)
    val textColor = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() },
        elevation = if (isSelected) CardDefaults.cardElevation(4.dp) else CardDefaults.cardElevation(1.dp),
        colors = CardDefaults.cardColors(containerColor = backgroundColor),
        border = BorderStroke(1.dp, borderColor)
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            RadioButton(
                selected = isSelected,
                onClick = onClick,
                colors = RadioButtonDefaults.colors(
                    selectedColor = MaterialTheme.colorScheme.primary
                )
            )
            Text(
                text = text,
                modifier = Modifier.padding(start = 8.dp),
                color = textColor,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
            )
        }
    }
}
// Отдельная функция для кнопок ролей (чтобы не повторять код)
// ЭКРАН ПСИХОЛОГИЧЕСКОГО ТЕСТА (ИСПРАВЛЕННАЯ ВЕРСИЯ)
@Composable
fun PsychologyTestScreen(
    onBackToMain: () -> Unit,
    onMenuClick: () -> Unit
) {
    // Список вопросов для теста
    val questions = listOf(
        "1. Я часто чувствую себя спокойно и расслабленно",
        "2. Мне легко знакомиться с новыми людьми",
        "3. Я часто переживаю из-за мелочей",
        "4. Мне нравится работать в команде",
        "5. Я часто чувствую усталость без причины",
        "6. Мне легко принимать решения",
        "7. Я часто критикую себя",
        "8. Я легко адаптируюсь к изменениям",
        "9. Мне трудно сказать 'нет'",
        "10. Я доволен(льна) своей жизнью"
     )
    // Текущий вопрос (от 0 до 9)
    var currentQuestion by remember { mutableStateOf(0) }
    // Ответы пользователя
    var answers by remember { mutableStateOf(List(10) { -1 }) }
    // Показывать ли результат
    var showResult by remember { mutableStateOf(false) }
    // Если показываем результат
    if (showResult) {
        TestResultScreen(
            answers = answers,
            onBackToMain = onBackToMain
        )
        return
    }
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.White)
    ) {
        // ШАПКА С КНОПКОЙ МЕНЮ И НАЗАД
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Кнопка меню (три полоски)
            IconButton(onClick = onMenuClick) {
                Icon(
                    imageVector = Icons.Default.Menu,
                    contentDescription = "Меню",
                    tint = Color(0xFF6A5AE0)
                )
            }

            Text(
                text = "Психологический тест",
                style = MaterialTheme.typography.headlineSmall,
                color = Color(0xFF6A5AE0)
            )

            // Кнопка назад
            IconButton(onClick = onBackToMain) {
                Icon(
                    imageVector = Icons.Default.ArrowBack,
                    contentDescription = "Назад",
                    tint = Color(0xFF6A5AE0)
                )
            }
        }

        // ОСНОВНОЙ КОНТЕНТ
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .padding(24.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Прогресс бар
            Text(
                text = "Вопрос ${currentQuestion + 1}/10",
                style = MaterialTheme.typography.bodySmall,
                color = Color.Gray
            )

            LinearProgressIndicator(
                progress = (currentQuestion + 1) / 10f,
                modifier = Modifier.fillMaxWidth(),
                color = Color(0xFF6A5AE0)
            )

            // Текст вопроса
            Text(
                text = questions[currentQuestion],
                style = MaterialTheme.typography.headlineSmall,
                modifier = Modifier.fillMaxWidth()
            )

            // Варианты ответов
            Text("Насколько это похоже на вас?")

            val options = listOf(
                "Совсем не похоже" to 0,
                "Скорее не похоже" to 1,
                "Затрудняюсь ответить" to 2,
                "Скорее похоже" to 3,
                "Очень похоже" to 4
            )

            options.forEach { (text, value) ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable {
                            val newAnswers = answers.toMutableList()
                            newAnswers[currentQuestion] = value
                            answers = newAnswers
                        },
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    RadioButton(
                        selected = answers[currentQuestion] == value,
                        onClick = {
                            val newAnswers = answers.toMutableList()
                            newAnswers[currentQuestion] = value
                            answers = newAnswers
                        },
                        colors = RadioButtonDefaults.colors(
                            selectedColor = Color(0xFF6A5AE0)
                        )
                    )
                    Text(
                        text = text,
                        modifier = Modifier.padding(start = 8.dp)
                    )
                }
            }
        }

        // КНОПКИ НАВИГАЦИИ
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // Кнопка "Назад"
            if (currentQuestion > 0) {
                Button(
                    onClick = { currentQuestion-- },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color.LightGray
                    )
                ) {
                    Text("Назад", color = Color.Black)
                }
            } else {
                Spacer(modifier = Modifier.width(80.dp))
            }

            // Кнопка "Далее" или "Завершить"
            if (currentQuestion < 9) {
                Button(
                    onClick = { currentQuestion++ },
                    enabled = answers[currentQuestion] != -1,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFF6A5AE0)
                    )
                ) {
                    Text("Далее", color = Color.White)
                }
            } else {
                Button(
                    onClick = { showResult = true },
                    enabled = answers[currentQuestion] != -1,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFF6A5AE0)
                    )
                ) {
                    Text("Завершить тест", color = Color.White)
                }
            }
        }
    }
}
// ЭКРАН РЕЗУЛЬТАТОВ ТЕСТА (ОБНОВЛЁННАЯ)
@Composable
fun TestResultScreen(
    answers: List<Int>,
    onBackToMain: () -> Unit
    // ← УДАЛИТЬ: currentTheme: ColorTheme = ColorTheme.LIGHT,
    // ← УДАЛИТЬ: onThemeChange: (ColorTheme) -> Unit = {}
) {
    // Подсчет результатов (простая логика)
    val totalScore = answers.sum()
    val resultText = when {
        totalScore <= 15 -> "Низкий уровень эмоционального благополучия. Рекомендуется обратиться к психологу."
        totalScore <= 25 -> "Средний уровень. Есть над чем работать, но в целом стабильное состояние."
        else -> "Высокий уровень эмоционального благополучия. Продолжайте в том же духе!"
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp)
            .background(Color.White), // ← ПРОСТО БЕЛЫЙ ФОН
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = "Результаты теста",
            style = MaterialTheme.typography.headlineMedium
        )

        Spacer(modifier = Modifier.height(32.dp))

        // Показываем общий балл
        Card(
            modifier = Modifier.fillMaxWidth(),
            elevation = CardDefaults.cardElevation(4.dp)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("Ваш результат:")
                Text(
                    text = "$totalScore/40 баллов",
                    style = MaterialTheme.typography.headlineMedium,
                    color = Color(0xFF6A5AE0)
                )
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Интерпретация
        Text(
            text = resultText,
            style = MaterialTheme.typography.bodyLarge,
            modifier = Modifier.fillMaxWidth(),
            textAlign = TextAlign.Center
        )

        Spacer(modifier = Modifier.height(32.dp))

        // Кнопка для возврата
        Button(
            onClick = onBackToMain,
            modifier = Modifier
                .fillMaxWidth()
                .height(50.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = Color(0xFF6A5AE0)
            )
        ) {
            Text("Вернуться на главную", color = Color.White)
        }
    }
}
// ЭКРАН УЧИТЕЛЯ - ПОЛНАЯ ВЕРСИЯ (ИСПРАВЛЕННАЯ)
@Composable
fun TeacherScreen(
    onBackToMain: () -> Unit,
    onMenuClick: () -> Unit
) {
    val context = LocalContext.current

    // Список учеников (тестовые данные)
    val students = remember {
        listOf(
            Student(1, "Анна", "Иванова", 28, "Сегодня", true),
            Student(2, "Максим", "Петров", 32, "Вчера", false),
            Student(3, "София", "Сидорова", null, "2 дня назад", true),
            Student(4, "Дмитрий", "Кузнецов", 19, "Неделю назад", false),
            Student(5, "Елена", "Смирнова", 35, "Сегодня", false)
        )
    }

    var searchText by remember { mutableStateOf("") }

    // Фильтрация учеников по поиску
    val filteredStudents = students.filter { student ->
        student.firstName.contains(searchText, ignoreCase = true) ||
                student.lastName.contains(searchText, ignoreCase = true)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF5F7FF))
    ) {
        // ШАПКА С КНОПКОЙ МЕНЮ И НАЗАД
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Кнопка меню (три полоски)
            IconButton(onClick = onMenuClick) {
                Icon(
                    imageVector = Icons.Default.Menu,
                    contentDescription = "Меню",
                    tint = Color(0xFF6A5AE0)
                )
            }

            Text(
                text = "Панель учителя",
                style = MaterialTheme.typography.headlineSmall,
                color = Color(0xFF6A5AE0)
            )

            // Кнопка назад
            IconButton(onClick = onBackToMain) {
                Icon(
                    imageVector = Icons.Default.ArrowBack,
                    contentDescription = "Назад",
                    tint = Color(0xFF6A5AE0)
                )
            }
        }

        // КАРТОЧКА С ПОИСКОМ
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            elevation = CardDefaults.cardElevation(4.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Text(
                    text = "Учеников: ${students.size}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = Color.Gray
                )

                Spacer(modifier = Modifier.height(16.dp))

                // ПОИСК
                OutlinedTextField(
                    value = searchText,
                    onValueChange = { searchText = it },
                    label = { Text("🔍 Поиск ученика...") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }

        // СПИСОК УЧЕНИКОВ
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(filteredStudents) { student ->
                StudentCard(
                    student = student,
                    onChatClick = {
                        android.widget.Toast.makeText(
                            context,
                            "Чат с ${student.firstName} ${student.lastName}",
                            android.widget.Toast.LENGTH_SHORT
                        ).show()
                    }
                )
            }
        }

        // КНОПКА НАЗАД
        Button(
            onClick = onBackToMain,
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .height(50.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = Color(0xFF6A5AE0)
            )
        ) {
            Text("Вернуться на главную", color = Color.White)
        }
    }
}

// КАРТОЧКА УЧЕНИКА В СПИСКЕ
@Composable
fun StudentCard(student: Student, onChatClick: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onChatClick() },
        elevation = CardDefaults.cardElevation(2.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // ЛЕВАЯ ЧАСТЬ - ИНФОРМАЦИЯ
            Column(
                modifier = Modifier.weight(1f)
            ) {
                // Имя и фамилия
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "${student.firstName} ${student.lastName}",
                        style = MaterialTheme.typography.bodyLarge,
                        fontWeight = FontWeight.Bold
                    )

                    // Индикатор непрочитанных сообщений
                    if (student.hasUnreadMessages) {
                        Spacer(modifier = Modifier.width(8.dp))
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .background(Color.Red, CircleShape)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))

                // Результат теста
                if (student.testScore != null) {
                    val scoreColor = when {
                        student.testScore <= 15 -> Color(0xFFE53935) // красный
                        student.testScore <= 25 -> Color(0xFFFB8C00) // оранжевый
                        else -> Color(0xFF43A047) // зеленый
                    }

                    Text(
                        text = "Результат теста: ${student.testScore}/40 баллов",
                        style = MaterialTheme.typography.bodyMedium,
                        color = scoreColor
                    )
                } else {
                    Text(
                        text = "Тест не пройден",
                        style = MaterialTheme.typography.bodyMedium,
                        color = Color.Gray
                    )
                }

                Spacer(modifier = Modifier.height(4.dp))

                // Последняя активность
                Text(
                    text = "Был(а) в сети: ${student.lastActive}",
                    style = MaterialTheme.typography.bodySmall,
                    color = Color.Gray
                )
            }

            // ПРАВАЯ ЧАСТЬ - КНОПКА ЧАТА
            Button(
                onClick = onChatClick,
                modifier = Modifier
                    .height(36.dp)
                    .padding(start = 8.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFF6A5AE0)
                )
            ) {
                Text("💬 Чат", fontSize = 12.sp)
            }
        }
    }
}
@Composable
fun AdminScreen(
    onBackToMain: () -> Unit,
    onMenuClick: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF5F7FF))
    ) {
        // ШАПКА С КНОПКОЙ МЕНЮ И НАЗАД
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Кнопка меню (три полоски)
            IconButton(onClick = onMenuClick) {
                Icon(
                    imageVector = Icons.Default.Menu,
                    contentDescription = "Меню",
                    tint = Color(0xFF6A5AE0)
                )
            }

            Text(
                text = "Панель администратора",
                style = MaterialTheme.typography.headlineSmall,
                color = Color(0xFF6A5AE0)
            )

            // Кнопка назад
            IconButton(onClick = onBackToMain) {
                Icon(
                    imageVector = Icons.Default.ArrowBack,
                    contentDescription = "Назад",
                    tint = Color(0xFF6A5AE0)
                )
            }
        }

        // ОСНОВНОЙ КОНТЕНТ
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .padding(24.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "⚙️ Панель администратора",
                style = MaterialTheme.typography.headlineMedium,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(32.dp))

            Text(
                text = "Здесь будут все права управления приложением",
                style = MaterialTheme.typography.bodyLarge,
                textAlign = TextAlign.Center
            )
        }

        // КНОПКА НАЗАД
        Button(
            onClick = onBackToMain,
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .height(50.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = Color(0xFF6A5AE0)
            )
        ) {
            Text("Вернуться на главную", color = Color.White)
        }
    }
}
@Composable
fun AdminRegistrationScreen(
    onBackToMain: () -> Unit,
    onAdminRegistered: () -> Unit  // ← После успешной регистрации переходим в админ-панель
) {
    var adminName by remember { mutableStateOf("") }
    var adminEmail by remember { mutableStateOf("") }
    var adminPassword by remember { mutableStateOf("") }
    var adminCode by remember { mutableStateOf("") } // Секретный код для админа

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF5F7FF))
    ) {
        // ШАПКА
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Кнопка назад
            IconButton(onClick = onBackToMain) {
                Icon(
                    imageVector = Icons.Default.ArrowBack,
                    contentDescription = "Назад",
                    tint = Color(0xFF6A5AE0)
                )
            }

            Text(
                text = "Регистрация администратора",
                style = MaterialTheme.typography.headlineSmall,
                color = Color(0xFF6A5AE0)
            )

            Spacer(modifier = Modifier.size(48.dp))
        }

        // ОСНОВНОЙ КОНТЕНТ
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp),
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            // ЗАГОЛОВОК АДМИНА
            Text(
                text = "⚙️ Регистрация администратора",
                style = MaterialTheme.typography.headlineLarge,
                color = Color(0xFF6A5AE0),
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth()
            )

            Text(
                text = "Доступ только для авторизованного персонала",
                style = MaterialTheme.typography.bodyLarge,
                color = Color.Gray,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(16.dp))

            // КАРТОЧКА С ФОРМОЙ АДМИНА
            Card(
                modifier = Modifier.fillMaxWidth(),
                elevation = CardDefaults.cardElevation(6.dp)
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    // Имя администратора
                    OutlinedTextField(
                        value = adminName,
                        onValueChange = { adminName = it },
                        label = { Text("ФИО администратора") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = TextFieldDefaults.colors(
                            focusedIndicatorColor = Color(0xFF6A5AE0),
                            unfocusedIndicatorColor = Color(0xFF6A5AE0).copy(alpha = 0.5f)
                        )
                    )

                    // Email
                    OutlinedTextField(
                        value = adminEmail,
                        onValueChange = { adminEmail = it },
                        label = { Text("Служебный email") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = TextFieldDefaults.colors(
                            focusedIndicatorColor = Color(0xFF6A5AE0),
                            unfocusedIndicatorColor = Color(0xFF6A5AE0).copy(alpha = 0.5f)
                        )
                    )

                    // Пароль
                    OutlinedTextField(
                        value = adminPassword,
                        onValueChange = { adminPassword = it },
                        label = { Text("Пароль") },
                        modifier = Modifier.fillMaxWidth(),
                        visualTransformation = PasswordVisualTransformation(),
                        colors = TextFieldDefaults.colors(
                            focusedIndicatorColor = Color(0xFF6A5AE0),
                            unfocusedIndicatorColor = Color(0xFF6A5AE0).copy(alpha = 0.5f)
                        )
                    )

                    // Секретный код доступа
                    OutlinedTextField(
                        value = adminCode,
                        onValueChange = { adminCode = it },
                        label = { Text("Секретный код доступа") },
                        placeholder = { Text("Только для IT-отдела") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = TextFieldDefaults.colors(
                            focusedIndicatorColor = Color.Red,
                            unfocusedIndicatorColor = Color.Red.copy(alpha = 0.5f)
                        )
                    )

                    // ПОДСКАЗКА ДЛЯ ТЕСТА
                    Text(
                        text = "Для теста используйте код: 1234",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.Gray,
                        fontStyle = FontStyle.Italic
                    )

                    // КНОПКА РЕГИСТРАЦИИ АДМИНА
                    Button(
                        onClick = {
                            if (adminName.isNotEmpty() && adminEmail.isNotEmpty() &&
                                adminPassword.isNotEmpty() && adminCode == "1234") {
                                // Успешная регистрация админа
                                onAdminRegistered()
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFF6A5AE0)
                        ),
                        enabled = adminName.isNotEmpty() && adminEmail.isNotEmpty() &&
                                adminPassword.isNotEmpty() && adminCode == "1234"
                    ) {
                        Text("🔐 Зарегистрировать администратора", color = Color.White)
                    }
                }
            }

            // ИНФОРМАЦИЯ ДЛЯ АДМИНА
            Card(
                modifier = Modifier.fillMaxWidth(),
                elevation = CardDefaults.cardElevation(2.dp),
                colors = CardDefaults.cardColors(
                    containerColor = Color(0xFFFFF8E1)
                )
            ) {
                Column(
                    modifier = Modifier.padding(16.dp)
                ) {
                    Text(
                        text = "⚠️ Внимание!",
                        style = MaterialTheme.typography.bodyMedium,
                        color = Color(0xFFE65100),
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Администратор имеет полный доступ ко всем функциям приложения, включая управление пользователями и настройки системы.",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color(0xFFE65100)
                    )
                }
            }
        }
    }
}