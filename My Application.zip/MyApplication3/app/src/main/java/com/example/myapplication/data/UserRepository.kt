package com.example.myapplication.data

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class UserRepository(private val userDao: UserDao) {

    // РЕГИСТРАЦИЯ нового пользователя (ВЕРСИЯ ДЛЯ LONG)
    suspend fun registerUser(
        username: String,
        password: String,
        firstName: String,
        lastName: String,
        role: String
    ): Long {
        val user = User(
            id = 0, // Room сам сгенерирует ID при autoGenerate = true
            username = username,
            password = password,
            firstName = firstName,
            lastName = lastName,
            role = role,
            avatarColor = generateColorFromName(username)
        )
        return userDao.insertUser(user) // Возвращает сгенерированный ID
    }

    // СОЗДАНИЕ пользователя (удаляем старый метод с UUID - больше не нужен)
    suspend fun createUser(
        username: String,
        role: String,
        avatarColor: Int? = null
    ): Long { // ← Возвращаем Long
        val user = User(
            id = 0, // Room сам сгенерирует
            username = username,
            password = "123456", // Дефолтный пароль
            firstName = username.split(".").firstOrNull()?.capitalize() ?: "User",
            lastName = username.split(".").lastOrNull()?.capitalize() ?: "User",
            role = role,
            avatarColor = avatarColor ?: generateColorFromName(username)
        )
        return userDao.insertUser(user) // Возвращает сгенерированный ID
    }

    // АУТЕНТИФИКАЦИЯ
    suspend fun authenticate(username: String, password: String): User? {
        return userDao.authenticate(username, password)
    }

    // ПОЛУЧЕНИЕ пользователя по ID (ВЕРСИЯ ДЛЯ LONG)
    suspend fun getUserById(userId: Long): User? {
        return userDao.getUserById(userId)
    }

    // ПОЛУЧЕНИЕ пользователя по username
    suspend fun getUserByUsername(username: String): User? {
        return userDao.getUserByUsername(username)
    }

    // ПОЛУЧЕНИЕ пользователей по роли
    fun getUsersByRole(role: String): Flow<List<User>> {
        return userDao.getUsersByRole(role)
    }

    // Специальные методы для удобства
    fun getStudents(): Flow<List<User>> {
        return getUsersByRole("ученик") // Используем русские названия
    }

    fun getTeachers(): Flow<List<User>> {
        return getUsersByRole("учитель") // Используем русские названия
    }

    fun getAllUsers(): Flow<List<User>> {
        return userDao.getAllUsers()
    }

    suspend fun isUsernameAvailable(username: String): Boolean {
        return userDao.checkUsernameExists(username) == 0
    }

    suspend fun updateAvatarColor(userId: Long, color: Int) {
        val user = getUserById(userId)
        user?.let {
            val updatedUser = it.copy(avatarColor = color)
            userDao.updateUser(updatedUser)
        }
    }

    suspend fun updatePassword(userId: Long, newPassword: String) {
        val user = getUserById(userId)
        user?.let {
            val updatedUser = it.copy(password = newPassword)
            userDao.updateUser(updatedUser)
        }
    }

    private fun generateColorFromName(name: String): Int {
        val colors = listOf(
            0xFFFF6B6B.toInt(),
            0xFF4ECDC4.toInt(),
            0xFFFFD166.toInt(),
            0xFF6A0572.toInt(),
            0xFF06D6A0.toInt(),
            0xFF118AB2.toInt()
        )
        val index = kotlin.math.abs(name.hashCode()) % colors.size
        return colors[index]
    }
}