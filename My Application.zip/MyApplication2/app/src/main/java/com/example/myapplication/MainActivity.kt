package com.example.myapplication

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.clickable
import androidx.compose.ui.graphics.Color
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.sp


class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                // Показываем главный экран приложения
                PsychologyApp()
            }
        }
    }
}
// Главное приложение, которое управляет экранами
@Composable
fun PsychologyApp() {
    // Переменная для отслеживания текущего экрана
    var currentScreen by remember { mutableStateOf("registration") }

    // Показываем нужный экран в зависимости от состояния
    when (currentScreen) {
        "registration" -> RegistrationScreen(
            onStartTest = { currentScreen = "test" }  // Переход на тест
        )
        "test" -> PsychologyTestScreen(
            onBackToMain = { currentScreen = "registration" }  // Возврат на главную
        )
    }
}

// ЭКРАН РЕГИСТРАЦИИ
@Composable
fun RegistrationScreen(onStartTest: () -> Unit) {
    var firstName by remember { mutableStateOf("") }
    var lastName by remember { mutableStateOf("") }
    var selectedRole by remember { mutableStateOf(0) }
    val context = LocalContext.current  // ← ВАЖНО: получаем context здесь

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp)
            .background(Color(0xFFF5F7FF)),
        verticalArrangement = Arrangement.Center
    ) {
        // Заголовок
        Text(
            text = "👋 Добро пожаловать!",
            style = MaterialTheme.typography.headlineLarge,
            color = Color(0xFF6A5AE0),
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(8.dp))

        Text(
            text = "Психологический помощник",
            style = MaterialTheme.typography.bodyLarge,
            color = Color(0xFF6A5AE0).copy(alpha = 0.8f),
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(32.dp))

        // Карточка с формой
        Card(
            modifier = Modifier.fillMaxWidth(),
            elevation = CardDefaults.cardElevation(4.dp)
        ) {
            Column(
                modifier = Modifier.padding(24.dp),
                verticalArrangement = Arrangement.spacedBy(20.dp)
            ) {
                Text(
                    text = "Регистрация",
                    style = MaterialTheme.typography.headlineSmall,
                    color = Color(0xFF6A5AE0)
                )

                // Поля ввода
                OutlinedTextField(
                    value = firstName,
                    onValueChange = { firstName = it },
                    label = { Text("Имя") },
                    modifier = Modifier.fillMaxWidth(),
                    colors = TextFieldDefaults.colors(
                        focusedIndicatorColor = Color(0xFF6A5AE0),
                        unfocusedIndicatorColor = Color(0xFF6A5AE0).copy(alpha = 0.5f)
                    )
                )

                OutlinedTextField(
                    value = lastName,
                    onValueChange = { lastName = it },
                    label = { Text("Фамилия") },
                    modifier = Modifier.fillMaxWidth(),
                    colors = TextFieldDefaults.colors(
                        focusedIndicatorColor = Color(0xFF6A5AE0),
                        unfocusedIndicatorColor = Color(0xFF6A5AE0).copy(alpha = 0.5f)
                    )
                )

// Выбор роли - ТРИ КНОПКИ С МАЛЕНЬКИМИ ОТСТУПАМИ
                Text(
                text = "Выберите роль:",
                style = MaterialTheme.typography.bodyMedium,
                modifier = Modifier.padding(bottom = 8.dp)
            )
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    RoleButton(
                        text = "🎓 Ученик",
                        isSelected = selectedRole == 0,
                        onClick = { selectedRole = 0 }
                    )
                    RoleButton(
                        text = "👨‍🏫 Учитель",
                        isSelected = selectedRole == 1,
                        onClick = { selectedRole = 1 }
                    )

                    RoleButton(
                        text = "⚙️ Администратор",
                        isSelected = selectedRole == 2,
                        onClick = { selectedRole = 2 }
                    )
                }
                // Кнопка регистрации (ИСПРАВЛЕННАЯ - ДОБАВЛЯЕМ ПЕРЕХОД)
                Button(
                    onClick = {
                        if (firstName.isNotEmpty() && lastName.isNotEmpty()) {
                            val roleName = when (selectedRole) {
                                0 -> "ученик"
                                1 -> "учитель"
                                2 -> "администратор"
                                else -> "неизвестно"
                            }

                            // Показываем сообщение
                            android.widget.Toast.makeText(
                                context,
                                "Добро пожаловать, $firstName! Вы $roleName",
                                android.widget.Toast.LENGTH_SHORT
                            ).show()

                            // ★★★ ДОБАВЛЯЕМ ПЕРЕХОД НА ТЕСТ ★★★
                            onStartTest()
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFF6A5AE0)
                    ),
                    enabled = firstName.isNotEmpty() && lastName.isNotEmpty()
                ) {
                    Text("Начать тест 🚀", color = Color.White)
                }
            }
        }
    }
}
@Composable
fun RoleButton(text: String, isSelected: Boolean, onClick: () -> Unit) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .clickable { onClick() }
            .fillMaxWidth()
            .padding(8.dp)
    ) {
        RadioButton(
            selected = isSelected,
            onClick = onClick,
            colors = RadioButtonDefaults.colors(
                selectedColor = Color(0xFF6A5AE0)
            )
        )
        Text(
            text = text,
            modifier = Modifier.padding(start = 8.dp)
        )
    }
}
// Отдельная функция для кнопок ролей (чтобы не повторять код)
// ЭКРАН ПСИХОЛОГИЧЕСКОГО ТЕСТА (ИСПРАВЛЕННАЯ ВЕРСИЯ)
@Composable
fun PsychologyTestScreen(onBackToMain: () -> Unit) {  // ← ДОБАВЬТЕ ЭТОТ ПАРАМЕТР
    // Список вопросов для теста
    val questions = listOf(
        "1. Я часто чувствую себя спокойно и расслабленно",
        "2. Мне легко знакомиться с новыми людьми",
        "3. Я часто переживаю из-за мелочей",
        "4. Мне нравится работать в команде",
        "5. Я часто чувствую усталость без причины",
        "6. Мне легко принимать решения",
        "7. Я часто критикую себя",
        "8. Я легко адаптируюсь к изменениям",
        "9. Мне трудно сказать 'нет'",
        "10. Я доволен(льна) своей жизнью"
    )

    var currentQuestion by remember { mutableStateOf(0) }
    var answers by remember { mutableStateOf(List(10) { -1 }) }
    var showResult by remember { mutableStateOf(false) }

    if (showResult) {
        TestResultScreen(
            answers = answers,
            onBackToMain = onBackToMain  // ← ПЕРЕДАЕМ ДАЛЬШЕ
        )
        return
    }
    // ... остальной код PsychologyTestScreen БЕЗ ИЗМЕНЕНИЙ ...
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        verticalArrangement = Arrangement.Center
    ) {
        // Прогресс бар
        Text(
            text = "Вопрос ${currentQuestion + 1}/10",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Spacer(modifier = Modifier.height(8.dp))

        LinearProgressIndicator(
            progress = (currentQuestion + 1) / 10f,  // ИСПРАВЛЕНО: убрали {}
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(32.dp))

        // Текст вопроса
        Text(
            text = questions[currentQuestion],
            style = MaterialTheme.typography.headlineSmall,
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(32.dp))

        // Варианты ответов
        Text("Насколько это похоже на вас?")

        Spacer(modifier = Modifier.height(16.dp))

        val options = listOf(
            "Нет" to 0,
            "Скорее нет" to 1,
            "Затрудняюсь ответить" to 2,
            "Скорее да" to 3,
            "Да" to 4
        )

        options.forEach { (text, value) ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable {  // ИСПРАВЛЕНО: правильный синтаксис
                        // Сохраняем ответ
                        val newAnswers = answers.toMutableList()
                        newAnswers[currentQuestion] = value
                        answers = newAnswers
                    },
                verticalAlignment = Alignment.CenterVertically
            ) {
                RadioButton(
                    selected = answers[currentQuestion] == value,
                    onClick = {
                        val newAnswers = answers.toMutableList()
                        newAnswers[currentQuestion] = value
                        answers = newAnswers
                    }
                )
                Text(
                    text = text,
                    modifier = Modifier.padding(start = 8.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(32.dp))

        // Кнопки навигации
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // Кнопка "Назад"
            if (currentQuestion > 0) {
                Button(
                    onClick = { currentQuestion-- }
                ) {
                    Text("Назад")
                }
            } else {
                // Пустое место для выравнивания
                Spacer(modifier = Modifier.width(80.dp))
            }

            // Кнопка "Далее" или "Завершить"
            if (currentQuestion < 9) {
                Button(
                    onClick = { currentQuestion++ },
                    enabled = answers[currentQuestion] != -1
                ) {
                    Text("Далее")
                }
            } else {
                Button(
                    onClick = { showResult = true },
                    enabled = answers[currentQuestion] != -1
                ) {
                    Text("Завершить тест")
                }
            }
        }
    }
}
// ЭКРАН РЕЗУЛЬТАТОВ ТЕСТА
@Composable
fun TestResultScreen(answers: List<Int>, onBackToMain: () -> Unit) {  // ← ДОБАВЬТЕ ПАРАМЕТР
    val totalScore = answers.sum()
    val resultText = when {
        totalScore <= 15 -> "Низкий уровень эмоционального благополучия. Рекомендуется обратиться к психологу."
        totalScore <= 25 -> "Средний уровень. Есть над чем работать, но в целом стабильное состояние."
        else -> "Высокий уровень эмоционального благополучия. Продолжайте в том же духе!"
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = "Результаты теста",
            style = MaterialTheme.typography.headlineMedium
        )

        Spacer(modifier = Modifier.height(32.dp))

        Card(modifier = Modifier.fillMaxWidth()) {
            Column(
                modifier = Modifier.padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("Ваш результат:")
                Text(
                    text = "$totalScore/40 баллов",
                    style = MaterialTheme.typography.headlineMedium,
                    color = MaterialTheme.colorScheme.primary
                )
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        Text(
            text = resultText,
            style = MaterialTheme.typography.bodyLarge,
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(32.dp))

        // КНОПКА ТЕПЕРЬ РАБОТАЕТ!
        Button(
            onClick = onBackToMain  // ← ВОЗВРАТ НА ГЛАВНУЮ
        ) {
            Text("Вернуться на главную")
        }
    }
}