package com.example.myapplication.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import androidx.room.Delete
import kotlinx.coroutines.flow.Flow

@Dao
interface UserDao {

    // СОЗДАНИЕ пользователя
    @Insert
    suspend fun insertUser(user: User)

    // ОБНОВЛЕНИЕ пользователя
    @Update
    suspend fun updateUser(user: User)

    // ПОЛУЧЕНИЕ пользователя по ID
    @Query("SELECT * FROM users WHERE id = :userId")
    suspend fun getUserById(userId: String): User?

    // ПОЛУЧЕНИЕ всех пользователей по роли
    @Query("SELECT * FROM users WHERE role = :role")
    fun getUsersByRole(role: String): Flow<List<User>>

    // ПОЛУЧЕНИЕ всех пользователей
    @Query("SELECT * FROM users ORDER BY username")
    fun getAllUsers(): Flow<List<User>>

    // УДАЛЕНИЕ пользователя
    @Delete
    suspend fun deleteUser(user: User)

    // УДАЛЕНИЕ пользователя по ID
    @Query("DELETE FROM users WHERE id = :userId")
    suspend fun deleteUserById(userId: String)

    // ПРОВЕРКА: есть ли пользователь с таким username
    @Query("SELECT COUNT(*) FROM users WHERE username = :username")
    suspend fun checkUsernameExists(username: String): Int

    // Количество пользователей
    @Query("SELECT COUNT(*) FROM users")
    suspend fun getUserCount(): Int
}