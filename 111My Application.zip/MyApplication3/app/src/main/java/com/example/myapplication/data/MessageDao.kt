package com.example.myapplication.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface MessageDao {

    // Вставка сообщения
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMessage(message: MessageEntity): Long

    // Получение диалога между двумя пользователями
    @Query("""
        SELECT * FROM messages 
        WHERE (senderId = :userId1 AND receiverId = :userId2) 
           OR (senderId = :userId2 AND receiverId = :userId1) 
        ORDER BY timestamp ASC
    """)
    fun getConversation(userId1: String, userId2: String): Flow<List<MessageEntity>>

    // Пометить сообщения как прочитанные
    @Query("""
        UPDATE messages 
        SET isRead = 1 
        WHERE senderId = :senderId AND receiverId = :receiverId AND isRead = 0
    """)
    suspend fun markConversationAsRead(senderId: String, receiverId: String)

    // Количество непрочитанных сообщений
    @Query("""
        SELECT COUNT(*) FROM messages 
        WHERE receiverId = :userId AND isRead = 0
    """)
    suspend fun getUnreadCount(userId: String): Int

    // Все сообщения пользователя (входящие и исходящие)
    @Query("""
        SELECT * FROM messages 
        WHERE senderId = :userId OR receiverId = :userId 
        ORDER BY timestamp DESC
    """)
    fun getAllUserMessages(userId: String): Flow<List<MessageEntity>>

    // Получить последнее сообщение из каждого диалога
    @Query("""
        SELECT * FROM messages 
        WHERE id IN (
            SELECT MAX(id) 
            FROM messages 
            WHERE senderId = :userId OR receiverId = :userId 
            GROUP BY CASE 
                WHEN senderId = :userId THEN receiverId 
                ELSE senderId 
            END
        )
        ORDER BY timestamp DESC
    """)
    fun getDialogsPreview(userId: String): Flow<List<MessageEntity>>

    // Удалить сообщение
    @Delete
    suspend fun deleteMessage(message: MessageEntity)
}