package com.example.myapplication.data

import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import android.content.Context

@Database(
    entities = [
        User::class,              // ← уже есть
        TestResultEntity::class,  // ← добавляем
        MessageEntity::class      // ← добавляем
    ],
    version = 2,                  // ← увеличиваем версию!
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {

    abstract fun userDao(): UserDao
    abstract fun testResultDao(): TestResultDao  // ← добавляем
    abstract fun messageDao(): MessageDao        // ← добавляем

    companion object {
        // Singleton паттерн - база данных одна на всё приложение
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "psy_helper_db"  // Имя файла БД на устройстве
                )
                    .fallbackToDestructiveMigration() // Простые миграции
                    .build()

                INSTANCE = instance
                instance
            }
        }

        // Для тестирования: закрыть базу
        fun closeDatabase() {
            INSTANCE?.close()
            INSTANCE = null
        }
    }
}