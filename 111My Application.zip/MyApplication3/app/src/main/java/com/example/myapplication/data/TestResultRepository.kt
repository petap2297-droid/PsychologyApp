package com.example.myapplication.data

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class TestResultRepository(private val testResultDao: TestResultDao) {

    // СОХРАНЕНИЕ результата теста
    suspend fun saveTestResult(
        userId: String,
        studentName: String,
        score: Int,
        date: String,
        answers: List<Int>,
        recommendations: String,
        categoryScores: Map<String, Int>? = null
    ) {
        val entity = TestResultEntity(
            userId = userId,
            studentName = studentName,
            score = score,
            date = date,
            answersJson = answers.joinToString(","),
            recommendations = recommendations,
            categoryScores = categoryScores?.let {
                it.entries.joinToString(";") { (key, value) -> "$key:$value" }
            } ?: ""
        )
        testResultDao.insertTestResult(entity)
    }

    // ВЕРСИЯ ДЛЯ Int ID (удобно для вызова)
    suspend fun saveTestResult(
        userId: Int,
        studentName: String,
        score: Int,
        date: String,
        answers: List<Int>,
        recommendations: String
    ) {
        saveTestResult(
            userId = userId.toString(),
            studentName = studentName,
            score = score,
            date = date,
            answers = answers,
            recommendations = recommendations
        )
    }

    // ИСТОРИЯ тестов пользователя (версия для String)
    fun getTestHistory(userId: String): Flow<List<com.example.myapplication.TestResult>> {
        return testResultDao.getTestHistoryByUser(userId).map { entities ->
            entities.map { it.toDomainModel() }
        }
    }

    // ИСТОРИЯ тестов пользователя (версия для Int)
    fun getTestHistory(userId: Int): Flow<List<com.example.myapplication.TestResult>> {
        return getTestHistory(userId.toString())
    }

    // ПОСЛЕДНИЙ тест (версия для String)
    suspend fun getLastTestResult(userId: String): com.example.myapplication.TestResult? {
        return testResultDao.getLastTestResult(userId)?.toDomainModel()
    }

    // ПОСЛЕДНИЙ тест (версия для Int)
    suspend fun getLastTestResult(userId: Int): com.example.myapplication.TestResult? {
        return getLastTestResult(userId.toString())
    }

    // СРЕДНИЙ балл
    suspend fun getAverageScore(userId: String): Float? {
        return testResultDao.getAverageScore(userId)
    }

    suspend fun getAverageScore(userId: Int): Float? {
        return getAverageScore(userId.toString())
    }

    // Конвертация Entity → Domain Model (ИСПРАВЛЕННАЯ)
    private fun TestResultEntity.toDomainModel(): com.example.myapplication.TestResult {
        val answers = try {
            answersJson.split(",").mapNotNull { it.toIntOrNull() }
        } catch (e: Exception) {
            emptyList()
        }

        // Ключевое исправление: userId конвертируем в Int для TestResult
        return com.example.myapplication.TestResult(
            id = id.toInt(),
            studentId = this.userId.toIntOrNull() ?: 0, // Конвертируем String → Int
            studentName = studentName,
            score = score,
            date = date,
            answers = answers,
            recommendations = recommendations
        )
    }
}