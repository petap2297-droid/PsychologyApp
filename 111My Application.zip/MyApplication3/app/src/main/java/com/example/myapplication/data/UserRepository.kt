package com.example.myapplication.data

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.util.UUID

class UserRepository(private val userDao: UserDao) {

    suspend fun createUser(
        username: String,
        role: String,
        avatarColor: Int? = null
    ): String {
        val userId = UUID.randomUUID().toString()
        val user = User(
            id = userId,
            username = username,
            role = role,
            avatarColor = avatarColor ?: generateColorFromName(username)
        )
        userDao.insertUser(user)
        return userId
    }

    suspend fun getUserById(userId: String): User? {
        return userDao.getUserById(userId)
    }

    fun getCurrentUserFlow(userId: String): Flow<User?> {
        return userDao.getUsersByRole("") // временно
            .map { users -> users.find { it.id == userId } }
    }

    fun getStudents(): Flow<List<User>> {
        return userDao.getUsersByRole("student")
    }

    fun getTeachers(): Flow<List<User>> {
        return userDao.getUsersByRole("teacher")
    }

    suspend fun isUsernameAvailable(username: String): Boolean {
        return userDao.checkUsernameExists(username) == 0
    }

    suspend fun updateAvatarColor(userId: String, color: Int) {
        val user = getUserById(userId)
        user?.let {
            val updatedUser = it.copy(avatarColor = color)
            userDao.updateUser(updatedUser)
        }
    }

    // ИСПРАВЛЕННАЯ ФУНКЦИЯ:
    private fun generateColorFromName(name: String): Int {
        // Используем уже готовые цвета из Color.kt или Material Theme
        val colors = listOf(
            0xFFFF6B6B.toInt(), // красный
            0xFF4ECDC4.toInt(), // бирюзовый
            0xFFFFD166.toInt(), // желтый
            0xFF6A0572.toInt(), // фиолетовый
            0xFF06D6A0.toInt(), // зеленый
            0xFF118AB2.toInt()  // синий
        )
        val index = kotlin.math.abs(name.hashCode()) % colors.size
        return colors[index]
    }
}