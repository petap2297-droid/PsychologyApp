package com.example.myapplication

import android.content.Context
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class DataManager(
    private val context: Context,
    private val testResultRepository: com.example.myapplication.data.TestResultRepository
) {
    // Создаем LocalStorage внутри
    private val localStorage by lazy { LocalStorage(context) }

    // Получаем историю из Room (версия для Int ID)
    fun getTestHistoryFromRoom(userId: Int): Flow<List<TestResult>> {
        return flow {
            try {
                // Используем версию для Int
                testResultRepository.getTestHistory(userId).collect { history ->
                    emit(history)
                }
            } catch (e: Exception) {
                println("❌ Ошибка при загрузке истории: ${e.message}")
                emit(emptyList())
            }
        }
    }

    // Получаем историю из LocalStorage (старый способ)
    suspend fun getTestHistoryFromLocalStorage(): List<TestResult> {
        return withContext(Dispatchers.IO) {
            try {
                localStorage.loadTestHistory()
            } catch (e: Exception) {
                println("❌ Ошибка загрузки из LocalStorage: ${e.message}")
                emptyList()
            }
        }
    }

    // Сохранение теста (упрощенная версия)
    suspend fun saveTestResult(
        userId: Int,
        studentName: String,
        score: Int,
        date: String,
        answers: List<Int>,
        recommendations: String
    ) {
        withContext(Dispatchers.IO) {
            try {
                // 1. Сохраняем в Room (используем версию для Int)
                testResultRepository.saveTestResult(
                    userId = userId, // Передаем Int
                    studentName = studentName,
                    score = score,
                    date = date,
                    answers = answers,
                    recommendations = recommendations
                )
                println("✅ Тест сохранен в Room: $score баллов")

                // 2. Для совместимости - в LocalStorage
                val testResult = TestResult(
                    id = date.hashCode(),
                    studentId = userId,
                    studentName = studentName,
                    score = score,
                    date = date,
                    answers = answers,
                    recommendations = recommendations
                )
                localStorage.saveTestResult(testResult)
                println("✅ Тест также сохранен в LocalStorage")

            } catch (e: Exception) {
                println("❌ Ошибка сохранения: ${e.message}")
            }
        }
    }

    // Сохранение пользователя
    suspend fun saveUserData(userData: UserData, role: Int) {
        withContext(Dispatchers.IO) {
            try {
                localStorage.saveUserData(userData, role)
                println("✅ Пользователь сохранен: ${userData.fullName}, роль: $role")
            } catch (e: Exception) {
                println("❌ Ошибка сохранения пользователя: ${e.message}")
            }
        }
    }

    // Загрузка пользователя
    suspend fun loadUserData(): Pair<UserData?, Int> {
        return withContext(Dispatchers.IO) {
            try {
                localStorage.loadUserData()
            } catch (e: Exception) {
                println("❌ Ошибка загрузки пользователя: ${e.message}")
                Pair(null, 0)
            }
        }
    }

    // Очистка данных
    suspend fun clearUserData() {
        withContext(Dispatchers.IO) {
            try {
                localStorage.clearUserData()
                println("🧹 Данные пользователя очищены")
            } catch (e: Exception) {
                println("❌ Ошибка очистки данных: ${e.message}")
            }
        }
    }

    // Миграция старых данных (опционально, можно отключить)
    suspend fun migrateOldData(userId: Int) {
        withContext(Dispatchers.IO) {
            try {
                val oldHistory = localStorage.loadTestHistory()
                println("🔄 Найдено ${oldHistory.size} старых тестов для миграции")

                if (oldHistory.isNotEmpty()) {
                    var migratedCount = 0
                    oldHistory.forEach { testResult ->
                        // Проверяем, нет ли уже такого теста
                        val existing = testResultRepository.getLastTestResult(userId)
                        if (existing == null || existing.date != testResult.date) {
                            testResultRepository.saveTestResult(
                                userId = userId,
                                studentName = testResult.studentName,
                                score = testResult.score,
                                date = testResult.date,
                                answers = testResult.answers,
                                recommendations = testResult.recommendations
                            )
                            migratedCount++
                        }
                    }
                    println("✅ Успешно мигрировано $migratedCount тестов в Room")
                } else {
                    println("ℹ️ Нет старых тестов для миграции")
                }
            } catch (e: Exception) {
                // Не критичная ошибка - просто логируем
                println("⚠️ Миграция не удалась: ${e.message}")
                println("ℹ️ Приложение продолжит работу с LocalStorage")
            }
        }
    }

    // Для тестирования - получить количество тестов (ИСПРАВЛЕННЫЙ МЕТОД)
    suspend fun getTestCount(userId: Int): Int {
        return withContext(Dispatchers.IO) {
            try {
                val localStorageCount = localStorage.loadTestHistory().size

                // ИСПРАВЛЕНИЕ: вызываем first() внутри корутины
                val roomHistory = testResultRepository.getTestHistory(userId).first()
                val roomCount = roomHistory.size

                println("📊 LocalStorage: $localStorageCount, Room: $roomCount тестов")
                localStorageCount + roomCount
            } catch (e: Exception) {
                println("❌ Ошибка получения количества: ${e.message}")
                0
            }
        }
    }
}