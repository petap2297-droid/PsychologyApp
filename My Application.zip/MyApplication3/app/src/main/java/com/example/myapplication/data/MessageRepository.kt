package com.example.myapplication.data

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class MessageRepository(private val messageDao: MessageDao) {

    // ОСНОВНАЯ версия - Long
    suspend fun sendMessage(
        senderId: Long,    // ← Меняем на Long
        receiverId: Long,  // ← Меняем на Long
        senderName: String,
        message: String
    ) {
        val entity = MessageEntity(
            senderId = senderId,
            receiverId = receiverId,
            senderName = senderName,
            message = message,
            timestamp = System.currentTimeMillis(),
            isRead = false
        )
        messageDao.insertMessage(entity)
    }

    // ВЕРСИЯ для String (для совместимости)
    suspend fun sendMessage(
        senderId: String,
        receiverId: String,
        senderName: String,
        message: String
    ) {
        val senderIdLong = senderId.toLongOrNull() ?: 0L
        val receiverIdLong = receiverId.toLongOrNull() ?: 0L
        sendMessage(senderIdLong, receiverIdLong, senderName, message)
    }

    // ДИАЛОГ - основная версия Long
    fun getConversation(userId1: Long, userId2: Long): Flow<List<com.example.myapplication.ChatMessage>> {
        return messageDao.getConversation(userId1, userId2).map { entities ->
            entities.map { it.toDomainModel() }
        }
    }

    // ВЕРСИЯ для String
    fun getConversation(userId1: String, userId2: String): Flow<List<com.example.myapplication.ChatMessage>> {
        val userId1Long = userId1.toLongOrNull() ?: 0L
        val userId2Long = userId2.toLongOrNull() ?: 0L
        return getConversation(userId1Long, userId2Long)
    }

    // ПОМЕТКА как прочитанные - Long
    suspend fun markAsRead(userId: Long, senderId: Long) {
        messageDao.markConversationAsRead(senderId, userId) // senderId, receiverId
    }

    // ВЕРСИЯ для String
    suspend fun markAsRead(userId: String, senderId: String) {
        val userIdLong = userId.toLongOrNull() ?: 0L
        val senderIdLong = senderId.toLongOrNull() ?: 0L
        markAsRead(userIdLong, senderIdLong)
    }

    // НЕПРОЧИТАННЫЕ - Long
    suspend fun getUnreadCount(userId: Long): Int {
        return messageDao.getUnreadCount(userId)
    }

    // ВЕРСИЯ для String
    suspend fun getUnreadCount(userId: String): Int {
        val userIdLong = userId.toLongOrNull() ?: 0L
        return getUnreadCount(userIdLong)
    }

    // ВСЕ сообщения пользователя - Long
    fun getAllUserMessages(userId: Long): Flow<List<com.example.myapplication.ChatMessage>> {
        return messageDao.getAllUserMessages(userId).map { entities ->
            entities.map { it.toDomainModel() }
        }
    }

    // ВЕРСИЯ для String
    fun getAllUserMessages(userId: String): Flow<List<com.example.myapplication.ChatMessage>> {
        val userIdLong = userId.toLongOrNull() ?: 0L
        return getAllUserMessages(userIdLong)
    }

    // Конвертация Entity → Domain Model
    private fun MessageEntity.toDomainModel(): com.example.myapplication.ChatMessage {
        return com.example.myapplication.ChatMessage(
            id = id.toString(),
            senderId = senderId, // ← Уже Long, оставляем как есть
            receiverId = receiverId, // ← Уже Long, оставляем как есть
            senderName = senderName,
            message = message,
            timestamp = timestamp,
            isRead = isRead
        )
    }
}