package com.example.myapplication.data

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class MessageRepository(private val messageDao: MessageDao) {

    // ОТПРАВКА сообщения
    suspend fun sendMessage(
        senderId: String,
        receiverId: String,
        senderName: String,
        message: String
    ) {
        val entity = MessageEntity(
            senderId = senderId,
            receiverId = receiverId,
            senderName = senderName,
            message = message,
            timestamp = System.currentTimeMillis(),
            isRead = false
        )
        messageDao.insertMessage(entity)
    }

    // ПОЛУЧЕНИЕ диалога между двумя пользователями
    fun getConversation(userId1: String, userId2: String): Flow<List<com.example.myapplication.ChatMessage>> {
        return messageDao.getConversation(userId1, userId2).map { entities ->
            entities.map { it.toDomainModel() }
        }
    }

    // ПОМЕТКА сообщений как прочитанных
    suspend fun markAsRead(userId: String, senderId: String) {
        messageDao.markConversationAsRead(userId, senderId)
    }

    // КОЛИЧЕСТВО непрочитанных
    suspend fun getUnreadCount(userId: String): Int {
        return messageDao.getUnreadCount(userId)
    }

    // ВСЕ сообщения пользователя
    fun getAllUserMessages(userId: String): Flow<List<com.example.myapplication.ChatMessage>> {
        return messageDao.getAllUserMessages(userId).map { entities ->
            entities.map { it.toDomainModel() }
        }
    }

    // Конвертация Entity → Domain Model
    private fun MessageEntity.toDomainModel(): com.example.myapplication.ChatMessage {
        return com.example.myapplication.ChatMessage(
            id = id.toString(),
            senderId = senderId.toIntOrNull() ?: 0,
            receiverId = receiverId.toIntOrNull() ?: 0,
            senderName = senderName,
            message = message,
            timestamp = timestamp,
            isRead = isRead
        )
    }
}