// SyncManager.kt - УПРОЩЕННАЯ ИСПРАВЛЕННАЯ ВЕРСИЯ
package com.example.myapplication.data

import android.content.Context
import android.net.ConnectivityManager
import kotlinx.coroutines.flow.firstOrNull

class SyncManager(
    private val context: Context,
    private val firebaseRepo: FirebaseRepository,
    private val userRepository: UserRepository
    // Убираем messageRepository и testRepository из конструктора
) {
    // Проверка подключения к интернету
    fun isOnline(): Boolean {
        try {
            val connectivityManager = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val networkInfo = connectivityManager.activeNetworkInfo
            return networkInfo != null && networkInfo.isConnected
        } catch (e: Exception) {
            return false
        }
    }

    // ОСНОВНАЯ СИНХРОНИЗАЦИЯ
    suspend fun syncAllData() {
        if (!isOnline()) {
            println("🌐 [SyncManager] Нет интернета")
            return
        }

        try {
            println("🔄 [SyncManager] Начинаем синхронизацию...")

            // 1. Загружаем пользователей ИЗ Firebase в Room
            syncUsersFromFirebase()

            // 2. Отправляем локальных пользователей В Firebase
            syncUsersToFirebase()

            println("✅ [SyncManager] Синхронизация завершена")
        } catch (e: Exception) {
            println("❌ [SyncManager] Ошибка: ${e.message}")
        }
    }

    // ОТПРАВКА пользователей: Room → Firebase
    private suspend fun syncUsersToFirebase() {
        try {
            println("👥 [SyncManager] Отправка пользователей В Firebase...")

            val usersFlow = userRepository.getAllUsers()
            val users = usersFlow.firstOrNull() ?: emptyList()

            println("👥 [SyncManager] Найдено ${users.size} пользователей для отправки")

            for (user in users) {
                firebaseRepo.syncUser(user)
            }

            println("✅ [SyncManager] Пользователи отправлены в Firebase")
        } catch (e: Exception) {
            println("❌ [SyncManager] Ошибка отправки пользователей: ${e.message}")
        }
    }

    // ЗАГРУЗКА пользователей: Firebase → Room
    private suspend fun syncUsersFromFirebase() {
        try {
            println("👥 [SyncManager] Загрузка пользователей ИЗ Firebase...")

            val firebaseUsers = firebaseRepo.loadUsersFromFirebase()
            println("👥 [SyncManager] В Firebase найдено ${firebaseUsers.size} пользователей")

            var addedCount = 0

            for (firebaseUser in firebaseUsers) {
                val existingUser = userRepository.getUserById(firebaseUser.id)

                if (existingUser == null) {
                    // Добавляем в Room
                    val newId = userRepository.createUserFromFirebase(firebaseUser)
                    addedCount++
                    println("➕ [SyncManager] Добавлен пользователь: ${firebaseUser.username} (ID: $newId)")
                } else {
                    println("✓ [SyncManager] Пользователь уже есть: ${firebaseUser.username}")
                }
            }

            println("✅ [SyncManager] Загружено $addedCount новых пользователей из Firebase")

        } catch (e: Exception) {
            println("❌ [SyncManager] Ошибка загрузки пользователей: ${e.message}")
        }
    }

    // Синхронизация при регистрации
    suspend fun syncOnUserRegistration(user: User) {
        if (isOnline()) {
            firebaseRepo.syncUser(user)
        }
    }

    // Синхронизация при сохранении теста
    suspend fun syncOnTestSave(
        userId: Long,
        studentName: String,
        score: Int,
        date: String,
        answers: List<Int>,
        recommendations: String
    ) {
        if (isOnline()) {
            firebaseRepo.syncTestResult(
                userId = userId,
                studentName = studentName,
                score = score,
                date = date,
                answers = answers,
                recommendations = recommendations
            )
        }
    }

    // Синхронизация сообщения
    suspend fun syncOnMessageSend(
        senderId: Long,
        receiverId: Long,
        senderName: String,
        message: String
    ) {
        if (isOnline()) {
            println("📨 [SyncManager] Синхронизация сообщения в Firebase...")
            firebaseRepo.syncMessage(
                senderId = senderId,
                receiverId = receiverId,
                senderName = senderName,
                message = message
            )
        } else {
            println("🌐 [SyncManager] Нет интернета, сообщение сохранено локально")
        }
    }
}