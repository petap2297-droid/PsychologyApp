package com.example.myapplication

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.clickable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.material.icons.Icons
import androidx.compose.material3.IconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.border
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.graphics.Shape
import androidx.compose.foundation.BorderStroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll


// ДАННЫЕ ДЛЯ УПРАВЛЕНИЯ ТЕМОЙ
enum class ColorTheme { LIGHT, DARK, AUTO }

@Composable
fun rememberAppThemeState() = remember {
    mutableStateOf(ColorTheme.LIGHT)
}
// МОДЕЛЬ ДАННЫХ УЧЕНИКА
data class Student(
    val id: Int,
    val firstName: String,
    val lastName: String,
    val testScore: Int? = null,
    val lastActive: String = "Сегодня",
    val hasUnreadMessages: Boolean = false
)
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                // Показываем главный экран приложения
                PsychologyApp()
            }
        }
    }
}
@Composable
fun MyAppTheme(
    darkTheme: Boolean = false,
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) {
        // УЛУЧШЕННАЯ ТЕМНАЯ ТЕМА
        darkColorScheme(
            primary = Color(0xFFBB86FC),
            onPrimary = Color(0xFF000000),
            primaryContainer = Color(0xFF3700B3),
            onPrimaryContainer = Color(0xFFEADDFF),
            secondary = Color(0xFF03DAC6),
            onSecondary = Color(0xFF000000),
            background = Color(0xFF121212),       // Тёмный фон
            onBackground = Color(0xFFFFFFFF),     // Белый текст на тёмном
            surface = Color(0xFF1E1E1E),          // Тёмные карточки
            onSurface = Color(0xFFFFFFFF),        // Белый текст на карточках
            surfaceVariant = Color(0xFF2D2D2D),
            onSurfaceVariant = Color(0xFFC8C8C8)
        )
    } else {
        // СВЕТЛАЯ ТЕМА
        lightColorScheme(
            primary = Color(0xFF6A5AE0),
            onPrimary = Color(0xFFFFFFFF),
            primaryContainer = Color(0xFFE8E6FF),
            onPrimaryContainer = Color(0xFF1A0061),
            secondary = Color(0xFF625B71),
            onSecondary = Color(0xFFFFFFFF),
            background = Color(0xFFF5F7FF),       // Светлый фон
            onBackground = Color(0xFF1C1B1F),     // Тёмный текст на светлом
            surface = Color(0xFFFFFFFF),          // Белые карточки
            onSurface = Color(0xFF1C1B1F),        // Тёмный текст на карточках
            surfaceVariant = Color(0xFFE7E0EC),
            onSurfaceVariant = Color(0xFF49454F)
        )
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = MaterialTheme.typography,
        content = content
    )
}
// Главное приложение, которое управляет экранами
// Главное приложение с поддержкой тем
@Composable
fun PsychologyApp() {
    val themeState = rememberAppThemeState()
    var currentScreen by remember { mutableStateOf("registration") }
    var selectedUserRole by remember { mutableStateOf(0) }

    val isDarkTheme = when (themeState.value) {
        ColorTheme.LIGHT -> false
        ColorTheme.DARK -> true
        ColorTheme.AUTO -> false
    }

    // ПРОСТАЯ ВЕРСИЯ БЕЗ ТЕСТОВОЙ КНОПКИ
    MyAppTheme(darkTheme = isDarkTheme) {
        when (currentScreen) {
            "registration" -> RegistrationScreen(
                onStartTest = {
                    when (selectedUserRole) {
                        0 -> currentScreen = "test"
                        1 -> currentScreen = "teacher"
                        2 -> currentScreen = "admin"
                        else -> currentScreen = "test"
                    }
                },
                onRoleSelected = { role -> selectedUserRole = role },
                currentTheme = themeState.value,
                onThemeChange = { newTheme -> themeState.value = newTheme }
            )
            "test" -> PsychologyTestScreen(
                onBackToMain = { currentScreen = "registration" },
                currentTheme = themeState.value,
                onThemeChange = { newTheme -> themeState.value = newTheme }
            )
            "teacher" -> TeacherScreen(
                onBackToMain = { currentScreen = "registration" },
                currentTheme = themeState.value,
                onThemeChange = { newTheme -> themeState.value = newTheme }
            )
            "admin" -> AdminScreen(
                onBackToMain = { currentScreen = "registration" },
                currentTheme = themeState.value,
                onThemeChange = { newTheme -> themeState.value = newTheme }
            )
        }
    }
}
// ЭКРАН РЕГИСТРАЦИИ
@Composable
fun RegistrationScreen(
    onStartTest: () -> Unit,
    onRoleSelected: (Int) -> Unit = {},
    currentTheme: ColorTheme,
    onThemeChange: (ColorTheme) -> Unit
) {
    var firstName by remember { mutableStateOf("") }
    var lastName by remember { mutableStateOf("") }
    var selectedRole by remember { mutableStateOf(0) }
    val context = LocalContext.current

    LaunchedEffect(selectedRole) {
        onRoleSelected(selectedRole)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // ШАПКА С КНОПКОЙ ТЕМЫ
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Регистрация",
                style = MaterialTheme.typography.headlineSmall,
                color = MaterialTheme.colorScheme.primary
            )

            // Кнопка переключения темы
            Text(
                text = if (currentTheme == ColorTheme.DARK) "☀️" else "🌙",
                modifier = Modifier
                    .clickable {
                        onThemeChange(
                            if (currentTheme == ColorTheme.LIGHT) ColorTheme.DARK else ColorTheme.LIGHT
                        )
                    }
                    .padding(8.dp),
                fontSize = 20.sp,
                color = MaterialTheme.colorScheme.primary
            )
        }

        // ОСНОВНОЙ КОНТЕНТ БЕЗ СКРОЛЛА - используем вес для распределения пространства
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .padding(24.dp),
            verticalArrangement = Arrangement.Center, // ← ЦЕНТРИРУЕМ КОНТЕНТ
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Заголовок
            Text(
                text = "👋 Добро пожаловать!",
                style = MaterialTheme.typography.headlineLarge,
                color = MaterialTheme.colorScheme.primary,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth()
            )

            Text(
                text = "Психологический помощник",
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.8f),
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(32.dp))

            // Карточка с формой
            Card(
                modifier = Modifier.fillMaxWidth(),
                elevation = CardDefaults.cardElevation(4.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    verticalArrangement = Arrangement.spacedBy(20.dp)
                ) {
                    // Поля ввода
                    OutlinedTextField(
                        value = firstName,
                        onValueChange = { firstName = it },
                        label = {
                            Text(
                                "Имя",
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        },
                        modifier = Modifier.fillMaxWidth(),
                        colors = TextFieldDefaults.colors(
                            focusedIndicatorColor = MaterialTheme.colorScheme.primary,
                            unfocusedIndicatorColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.5f),
                            focusedLabelColor = MaterialTheme.colorScheme.primary,
                            unfocusedLabelColor = MaterialTheme.colorScheme.onSurfaceVariant,
                            cursorColor = MaterialTheme.colorScheme.primary,
                            focusedTextColor = MaterialTheme.colorScheme.onBackground,
                            unfocusedTextColor = MaterialTheme.colorScheme.onBackground
                        )
                    )

                    OutlinedTextField(
                        value = lastName,
                        onValueChange = { lastName = it },
                        label = {
                            Text(
                                "Фамилия",
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        },
                        modifier = Modifier.fillMaxWidth(),
                        colors = TextFieldDefaults.colors(
                            focusedIndicatorColor = MaterialTheme.colorScheme.primary,
                            unfocusedIndicatorColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.5f),
                            focusedLabelColor = MaterialTheme.colorScheme.primary,
                            unfocusedLabelColor = MaterialTheme.colorScheme.onSurfaceVariant,
                            cursorColor = MaterialTheme.colorScheme.primary,
                            focusedTextColor = MaterialTheme.colorScheme.onBackground,
                            unfocusedTextColor = MaterialTheme.colorScheme.onBackground
                        )
                    )

                    // Выбор роли
                    Text(
                        text = "Выберите роль:",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onBackground
                    )

                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        RoleButton(
                            text = "🎓 Ученик",
                            isSelected = selectedRole == 0,
                            onClick = { selectedRole = 0 }
                        )

                        RoleButton(
                            text = "👨‍🏫 Учитель",
                            isSelected = selectedRole == 1,
                            onClick = { selectedRole = 1 }
                        )

                        RoleButton(
                            text = "⚙️ Администратор",
                            isSelected = selectedRole == 2,
                            onClick = { selectedRole = 2 }
                        )
                    }

                    // Кнопка регистрации
                    Button(
                        onClick = {
                            if (firstName.isNotEmpty() && lastName.isNotEmpty()) {
                                onStartTest()
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.primary
                        ),
                        enabled = firstName.isNotEmpty() && lastName.isNotEmpty()
                    ) {
                        Text(
                            "Начать тест 🚀",
                            color = MaterialTheme.colorScheme.onPrimary
                        )
                    }
                }
            }
        }
    }
}
@Composable
fun RoleButton(text: String, isSelected: Boolean, onClick: () -> Unit) {
    val backgroundColor = if (isSelected) MaterialTheme.colorScheme.primary.copy(alpha = 0.1f) else Color.Transparent
    val borderColor = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline
    val textColor = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() },
        elevation = if (isSelected) CardDefaults.cardElevation(4.dp) else CardDefaults.cardElevation(1.dp),
        colors = CardDefaults.cardColors(containerColor = backgroundColor),
        border = BorderStroke(1.dp, borderColor)
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            RadioButton(
                selected = isSelected,
                onClick = onClick,
                colors = RadioButtonDefaults.colors(
                    selectedColor = MaterialTheme.colorScheme.primary
                )
            )
            Text(
                text = text,
                modifier = Modifier.padding(start = 8.dp),
                color = textColor,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
            )
        }
    }
}// Отдельная функция для кнопок ролей (чтобы не повторять код)
// ЭКРАН ПСИХОЛОГИЧЕСКОГО ТЕСТА (ИСПРАВЛЕННАЯ ВЕРСИЯ)
@Composable
fun PsychologyTestScreen(
    onBackToMain: () -> Unit,
    currentTheme: ColorTheme = ColorTheme.LIGHT,
    onThemeChange: (ColorTheme) -> Unit = {}
) {
    // Список вопросов для теста
    val questions = listOf(
        "1. Я часто чувствую себя спокойно и расслабленно",
        "2. Мне легко знакомиться с новыми людьми",
        "3. Я часто переживаю из-за мелочей",
        "4. Мне нравится работать в команде",
        "5. Я часто чувствую усталость без причины",
        "6. Мне легко принимать решения",
        "7. Я часто критикую себя",
        "8. Я легко адаптируюсь к изменениям",
        "9. Мне трудно сказать 'нет'",
        "10. Я доволен(льна) своей жизнью"
    )

    // Текущий вопрос (от 0 до 9)
    var currentQuestion by remember { mutableStateOf(0) }
    // Ответы пользователя
    var answers by remember { mutableStateOf(List(10) { -1 }) }
    // Показывать ли результат
    var showResult by remember { mutableStateOf(false) }

    // Если показываем результат
    if (showResult) {
        TestResultScreen(
            answers = answers,
            onBackToMain = onBackToMain,
            currentTheme = currentTheme,
            onThemeChange = onThemeChange
        )
        return
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp)
            .background(MaterialTheme.colorScheme.background),
        verticalArrangement = Arrangement.Center
    ) {
        // ШАПКА С КНОПКОЙ ТЕМЫ
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Психологический тест",
                style = MaterialTheme.typography.headlineSmall,
                color = MaterialTheme.colorScheme.primary
            )

            // Кнопка переключения темы
            Text(
                text = if (currentTheme == ColorTheme.DARK) "☀️" else "🌙",
                modifier = Modifier
                    .clickable {
                        onThemeChange(
                            if (currentTheme == ColorTheme.LIGHT) ColorTheme.DARK else ColorTheme.LIGHT
                        )
                    }
                    .padding(8.dp),
                fontSize = 20.sp,
                color = MaterialTheme.colorScheme.primary
            )
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Прогресс бар
        Text(
            text = "Вопрос ${currentQuestion + 1}/10",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Spacer(modifier = Modifier.height(8.dp))

        LinearProgressIndicator(
            progress = (currentQuestion + 1) / 10f,
            modifier = Modifier.fillMaxWidth(),
            color = MaterialTheme.colorScheme.primary
        )

        Spacer(modifier = Modifier.height(32.dp))

        // Текст вопроса
        Text(
            text = questions[currentQuestion],
            style = MaterialTheme.typography.headlineSmall,
            modifier = Modifier.fillMaxWidth(),
            color = MaterialTheme.colorScheme.onBackground
        )

        Spacer(modifier = Modifier.height(32.dp))

        // Варианты ответов
        Text(
            text = "Насколько это похоже на вас?",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onBackground
        )

        Spacer(modifier = Modifier.height(16.dp))

        val options = listOf(
            "Совсем не похоже" to 0,
            "Скорее не похоже" to 1,
            "Затрудняюсь ответить" to 2,
            "Скорее похоже" to 3,
            "Очень похоже" to 4
        )

        options.forEach { (text, value) ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable {
                        val newAnswers = answers.toMutableList()
                        newAnswers[currentQuestion] = value
                        answers = newAnswers
                    },
                verticalAlignment = Alignment.CenterVertically
            ) {
                RadioButton(
                    selected = answers[currentQuestion] == value,
                    onClick = {
                        val newAnswers = answers.toMutableList()
                        newAnswers[currentQuestion] = value
                        answers = newAnswers
                    },
                    colors = RadioButtonDefaults.colors(
                        selectedColor = MaterialTheme.colorScheme.primary
                    )
                )
                Text(
                    text = text,
                    modifier = Modifier.padding(start = 8.dp),
                    color = MaterialTheme.colorScheme.onBackground
                )
            }
        }

        Spacer(modifier = Modifier.height(32.dp))

        // Кнопки навигации
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // Кнопка "Назад"
            if (currentQuestion > 0) {
                Button(
                    onClick = { currentQuestion-- },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant
                    )
                ) {
                    Text(
                        text = "Назад",
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            } else {
                Spacer(modifier = Modifier.width(80.dp))
            }

            // Кнопка "Далее" или "Завершить"
            if (currentQuestion < 9) {
                Button(
                    onClick = { currentQuestion++ },
                    enabled = answers[currentQuestion] != -1,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.primary
                    )
                ) {
                    Text(
                        text = "Далее",
                        color = MaterialTheme.colorScheme.onPrimary
                    )
                }
            } else {
                Button(
                    onClick = { showResult = true },
                    enabled = answers[currentQuestion] != -1,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.primary
                    )
                ) {
                    Text(
                        text = "Завершить тест",
                        color = MaterialTheme.colorScheme.onPrimary
                    )
                }
            }
        }
    }
}
// ЭКРАН РЕЗУЛЬТАТОВ ТЕСТА
// ЭКРАН РЕЗУЛЬТАТОВ ТЕСТА (ОБНОВЛЁННАЯ)
@Composable
fun TestResultScreen(
    answers: List<Int>,
    onBackToMain: () -> Unit,
    currentTheme: ColorTheme = ColorTheme.LIGHT,
    onThemeChange: (ColorTheme) -> Unit = {}
) {
    // Подсчет результатов (простая логика)
    val totalScore = answers.sum()
    val resultText = when {
        totalScore <= 15 -> "Низкий уровень эмоционального благополучия. Рекомендуется обратиться к психологу."
        totalScore <= 25 -> "Средний уровень. Есть над чем работать, но в целом стабильное состояние."
        else -> "Высокий уровень эмоционального благополучия. Продолжайте в том же духе!"
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp)
            .background(MaterialTheme.colorScheme.background),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // ШАПКА С КНОПКОЙ ТЕМЫ
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Результаты теста",
                style = MaterialTheme.typography.headlineMedium,
                color = MaterialTheme.colorScheme.primary
            )

            // Кнопка переключения темы
            Text(
                text = if (currentTheme == ColorTheme.DARK) "☀️" else "🌙",
                modifier = Modifier
                    .clickable {
                        onThemeChange(
                            if (currentTheme == ColorTheme.LIGHT) ColorTheme.DARK else ColorTheme.LIGHT
                        )
                    }
                    .padding(8.dp),
                fontSize = 20.sp,
                color = MaterialTheme.colorScheme.primary
            )
        }

        Spacer(modifier = Modifier.height(32.dp))

        // Показываем общий балл
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surface
            )
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "Ваш результат:",
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = "$totalScore/40 баллов",
                    style = MaterialTheme.typography.headlineMedium,
                    color = MaterialTheme.colorScheme.primary
                )
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Интерпретация
        Text(
            text = resultText,
            style = MaterialTheme.typography.bodyLarge,
            modifier = Modifier.fillMaxWidth(),
            color = MaterialTheme.colorScheme.onBackground,
            textAlign = TextAlign.Center
        )

        Spacer(modifier = Modifier.height(32.dp))

        // Кнопка для возврата
        Button(
            onClick = onBackToMain,
            modifier = Modifier
                .fillMaxWidth()
                .height(50.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = MaterialTheme.colorScheme.primary
            )
        ) {
            Text(
                text = "Вернуться на главную",
                color = MaterialTheme.colorScheme.onPrimary
            )
        }
    }
}
// ЭКРАН УЧИТЕЛЯ - ПОЛНАЯ ВЕРСИЯ (ИСПРАВЛЕННАЯ)
@Composable
fun TeacherScreen(
    onBackToMain: () -> Unit,
    currentTheme: ColorTheme = ColorTheme.LIGHT,
    onThemeChange: (ColorTheme) -> Unit = {}
) {
    val context = LocalContext.current  // ← ДОБАВЬТЕ ЭТУ СТРОЧКУ
    // Список учеников (тестовые данные)
    val students = remember {
        listOf(
            Student(1, "Анна", "Иванова", 28, "Сегодня", true),
            Student(2, "Максим", "Петров", 32, "Вчера", false),
            Student(3, "София", "Сидорова", null, "2 дня назад", true),
            Student(4, "Дмитрий", "Кузнецов", 19, "Неделю назад", false),
            Student(5, "Елена", "Смирнова", 35, "Сегодня", false)
        )
    }

    var searchText by remember { mutableStateOf("") }

    // Фильтрация учеников по поиску
    val filteredStudents = students.filter { student ->
        student.firstName.contains(searchText, ignoreCase = true) ||
                student.lastName.contains(searchText, ignoreCase = true)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {

        // ШАПКА
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            elevation = CardDefaults.cardElevation(4.dp),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surface
            )
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                // Заголовок и кнопка темы
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "👨‍🏫 Панель учителя",
                        style = MaterialTheme.typography.headlineSmall,
                        color = MaterialTheme.colorScheme.primary
                    )

                    Text(
                        text = if (currentTheme == ColorTheme.DARK) "☀️" else "🌙",
                        modifier = Modifier
                            .clickable {
                                onThemeChange(
                                    if (currentTheme == ColorTheme.LIGHT) ColorTheme.DARK else ColorTheme.LIGHT
                                )
                            }
                            .padding(8.dp),
                        fontSize = 20.sp,
                        color = MaterialTheme.colorScheme.primary
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = "Учеников: ${students.size}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Spacer(modifier = Modifier.height(16.dp))

                // ПОИСК
                OutlinedTextField(
                    value = searchText,
                    onValueChange = { searchText = it },
                    label = { Text("🔍 Поиск ученика...") },
                    modifier = Modifier.fillMaxWidth(),
                    colors = TextFieldDefaults.colors(
                        focusedIndicatorColor = MaterialTheme.colorScheme.primary,
                        unfocusedIndicatorColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.5f),
                        focusedLabelColor = MaterialTheme.colorScheme.primary,
                        unfocusedLabelColor = MaterialTheme.colorScheme.onSurfaceVariant,
                        cursorColor = MaterialTheme.colorScheme.primary
                    )
                )
            }
        }

        // СПИСОК УЧЕНИКОВ
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(filteredStudents) { student ->
                StudentCard(
                    student = student,
                    onChatClick = {
                        android.widget.Toast.makeText(
                            context,  // ← ИСПОЛЬЗУЕМ context вместо LocalContext.current
                            "Чат с ${student.firstName} ${student.lastName}",
                            android.widget.Toast.LENGTH_SHORT
                        ).show()
                    }
                )
            }
        }

        // КНОПКА НАЗАД
        Button(
            onClick = onBackToMain,
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .height(50.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = MaterialTheme.colorScheme.primary
            )
        ) {
            Text(
                text = "Вернуться на главную",
                color = MaterialTheme.colorScheme.onPrimary
            )
        }

    }
}

// КАРТОЧКА УЧЕНИКА В СПИСКЕ
@Composable
fun StudentCard(student: Student, onChatClick: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onChatClick() },
        elevation = CardDefaults.cardElevation(2.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // ЛЕВАЯ ЧАСТЬ - ИНФОРМАЦИЯ
            Column(
                modifier = Modifier.weight(1f)
            ) {
                // Имя и фамилия
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "${student.firstName} ${student.lastName}",
                        style = MaterialTheme.typography.bodyLarge,
                        fontWeight = FontWeight.Bold
                    )

                    // Индикатор непрочитанных сообщений
                    if (student.hasUnreadMessages) {
                        Spacer(modifier = Modifier.width(8.dp))
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .background(Color.Red, CircleShape)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))

                // Результат теста
                if (student.testScore != null) {
                    val scoreColor = when {
                        student.testScore <= 15 -> Color(0xFFE53935) // красный
                        student.testScore <= 25 -> Color(0xFFFB8C00) // оранжевый
                        else -> Color(0xFF43A047) // зеленый
                    }

                    Text(
                        text = "Результат теста: ${student.testScore}/40 баллов",
                        style = MaterialTheme.typography.bodyMedium,
                        color = scoreColor
                    )
                } else {
                    Text(
                        text = "Тест не пройден",
                        style = MaterialTheme.typography.bodyMedium,
                        color = Color.Gray
                    )
                }

                Spacer(modifier = Modifier.height(4.dp))

                // Последняя активность
                Text(
                    text = "Был(а) в сети: ${student.lastActive}",
                    style = MaterialTheme.typography.bodySmall,
                    color = Color.Gray
                )
            }

            // ПРАВАЯ ЧАСТЬ - КНОПКА ЧАТА
            Button(
                onClick = onChatClick,
                modifier = Modifier
                    .height(36.dp)
                    .padding(start = 8.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFF6A5AE0)
                )
            ) {
                Text("💬 Чат", fontSize = 12.sp)
            }
        }
    }
}
@Composable
fun AdminScreen(
    onBackToMain: () -> Unit,
    currentTheme: ColorTheme = ColorTheme.LIGHT,
    onThemeChange: (ColorTheme) -> Unit = {}
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // ШАПКА С КНОПКОЙ ТЕМЫ
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "⚙️ Панель администратора",
                style = MaterialTheme.typography.headlineMedium,
                color = MaterialTheme.colorScheme.primary
            )

            // Кнопка переключения темы
            Text(
                text = if (currentTheme == ColorTheme.DARK) "☀️" else "🌙",
                modifier = Modifier
                    .clickable {
                        onThemeChange(
                            if (currentTheme == ColorTheme.LIGHT) ColorTheme.DARK else ColorTheme.LIGHT
                        )
                    }
                    .padding(8.dp),
                fontSize = 20.sp,
                color = MaterialTheme.colorScheme.primary
            )
        }

        Spacer(modifier = Modifier.height(32.dp))

        Text(
            text = "Здесь будут все права управления приложением",
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onBackground,
            textAlign = TextAlign.Center
        )

        Spacer(modifier = Modifier.height(32.dp))

        Button(
            onClick = onBackToMain,
            modifier = Modifier
                .fillMaxWidth()
                .height(50.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = MaterialTheme.colorScheme.primary
            )
        ) {
            Text(
                "Вернуться на главную",
                color = MaterialTheme.colorScheme.onPrimary
            )
        }
    }
}