package com.example.myapplication.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.asLiveData
import com.example.myapplication.data.TestResultRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class TestViewModel(private val testResultRepository: TestResultRepository) : ViewModel() {

    // State для истории тестов
    private val _testHistory = MutableStateFlow<List<com.example.myapplication.TestResult>>(emptyList())
    val testHistory: StateFlow<List<com.example.myapplication.TestResult>> = _testHistory.asStateFlow()

    // State для последнего теста
    private val _lastTestResult = MutableStateFlow<com.example.myapplication.TestResult?>(null)
    val lastTestResult: StateFlow<com.example.myapplication.TestResult?> = _lastTestResult.asStateFlow()

    init {
        // Загружаем данные при создании
        loadTestHistory("current_user_id") // временно, потом заменим на реальный ID
    }

    // СОХРАНЕНИЕ результата теста
    fun saveTestResult(
        userId: String,
        studentName: String,
        score: Int,
        date: String,
        answers: List<Int>,
        recommendations: String
    ) {
        viewModelScope.launch {
            testResultRepository.saveTestResult(
                userId = userId,
                studentName = studentName,
                score = score,
                date = date,
                answers = answers,
                recommendations = recommendations
            )
            loadTestHistory(userId)
        }
    }

    // ЗАГРУЗКА истории тестов
    private fun loadTestHistory(userId: String) {
        viewModelScope.launch {
            testResultRepository.getTestHistory(userId).collect { history ->
                _testHistory.value = history
                _lastTestResult.value = history.firstOrNull()
            }
        }
    }

    // СРЕДНИЙ балл
    suspend fun getAverageScore(userId: String): Float? {
        return testResultRepository.getAverageScore(userId)
    }
}