package com.example.myapplication.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "messages")
data class MessageEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val senderId: String,        // ID отправителя как String
    val receiverId: String,      // ID получателя как String
    val senderName: String,      // Имя отправителя (для отображения)
    val message: String,         // Текст сообщения
    val timestamp: Long = System.currentTimeMillis(), // Время отправки
    val isRead: Boolean = false  // Прочитано ли
) {
    // Дополнительный конструктор для удобства
    constructor(
        senderId: Int,
        receiverId: Int,
        senderName: String,
        message: String
    ) : this(
        senderId = senderId.toString(),
        receiverId = receiverId.toString(),
        senderName = senderName,
        message = message
    )
}