package com.example.myapplication.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.myapplication.webrtc.SimpleWebRTCManager
import kotlinx.coroutines.delay

@Composable
fun CallScreen(
    callerName: String,
    remoteUserId: String,
    currentUserId: String,
    isIncomingCall: Boolean = false,
    onCallFinished: () -> Unit
) {
    val context = LocalContext.current

    // Состояния
    var callStatus by remember { mutableStateOf(if (isIncomingCall) "Входящий звонок..." else "Соединение...") }
    var callDuration by remember { mutableStateOf(0) }
    var isMuted by remember { mutableStateOf(false) }
    var isSpeakerOn by remember { mutableStateOf(false) }
    var isCallActive by remember { mutableStateOf(false) }

    // Инициализация WebRTC Manager (Один раз при создании экрана)
    val webRTCManager = remember {
        SimpleWebRTCManager(context, currentUserId, remoteUserId).apply {
            onCallEstablished = {
                callStatus = "Разговор"
                isCallActive = true
            }
            onCallEnded = {
                callStatus = "Звонок завершен"
                isCallActive = false
                onCallFinished()
            }
        }
    }

    // Запрос разрешений
    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            webRTCManager.initialize()
            if (!isIncomingCall) webRTCManager.startCall()
        } else {
            callStatus = "❌ Нет доступа к микрофону"
        }
    }

    // Старт при запуске
    LaunchedEffect(Unit) {
        val hasPermission = ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        if (hasPermission) {
            webRTCManager.initialize()
            if (!isIncomingCall) webRTCManager.startCall()
        } else {
            permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    // Очистка при выходе
    DisposableEffect(Unit) {
        onDispose { webRTCManager.cleanup() }
    }

    // Таймер
    LaunchedEffect(isCallActive) {
        if (isCallActive) {
            val startTime = System.currentTimeMillis()
            while (isCallActive) {
                callDuration = ((System.currentTimeMillis() - startTime) / 1000).toInt()
                delay(1000)
            }
        }
    }

    // UI
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF202124)), // <--- ВАЖНО: ТЕМНЫЙ ФОН
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        // ИНФОРМАЦИЯ
        Column(
            modifier = Modifier.weight(1f),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Box(
                modifier = Modifier.size(120.dp).clip(CircleShape).background(Color(0xFF6A5AE0)),
                contentAlignment = Alignment.Center
            ) {
                Text(callerName.take(1).uppercase(), fontSize = 48.sp, color = Color.White)
            }
            Spacer(Modifier.height(24.dp))
            Text(callerName, color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            Text(if (isCallActive) formatTime(callDuration) else callStatus, color = Color.Gray, fontSize = 18.sp)
        }

        // КНОПКИ
        Row(
            modifier = Modifier.fillMaxWidth().padding(bottom = 48.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (isIncomingCall && !isCallActive) {
                // === ВХОДЯЩИЙ ЗВОНОК ===

                // Кнопка ОТКЛОНИТЬ
                CallButton(Icons.Default.CallEnd, Color.White, Color.Red, "Отклонить") {
                    webRTCManager.endCall()
                    onCallFinished()
                }

                // Кнопка ПРИНЯТЬ (Вот этот кусок мы меняем)
                CallButton(Icons.Default.Call, Color.White, Color.Green, "Принять") {
                    callStatus = "Подключение..." // Меняем текст на экране
                    webRTCManager.acceptCall()    // Отправляем ответ (ANSWER)
                }

            } else {
                // === ИДЕТ РАЗГОВОР (или исходящий) ===

                CallButton(if (isMuted) Icons.Default.MicOff else Icons.Default.Mic, Color.White, if (isMuted) Color.Red else Color.Gray, "Микрофон") {
                    isMuted = !isMuted
                    webRTCManager.toggleMute(isMuted)
                }

                CallButton(Icons.Default.CallEnd, Color.White, Color.Red, "Завершить", size = 72.dp) {
                    webRTCManager.endCall()
                    onCallFinished()
                }

                CallButton(if (isSpeakerOn) Icons.Default.VolumeUp else Icons.Default.VolumeOff, Color.White, if (isSpeakerOn) Color(0xFF6A5AE0) else Color.Gray, "Динамик") {
                    isSpeakerOn = !isSpeakerOn
                    webRTCManager.toggleSpeaker(isSpeakerOn)
                }
            }
        }
    }
}

@Composable
fun CallButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    tint: Color,
    bgColor: Color,
    label: String,
    size: androidx.compose.ui.unit.Dp = 56.dp,
    onClick: () -> Unit
) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        IconButton(
            onClick = onClick,
            modifier = Modifier.size(size).background(bgColor, CircleShape)
        ) {
            Icon(icon, null, tint = tint, modifier = Modifier.size(size * 0.5f))
        }
        Spacer(Modifier.height(4.dp))
        Text(label, color = Color.Gray, fontSize = 12.sp)
    }
}

private fun formatTime(seconds: Int): String {
    return String.format("%02d:%02d", seconds / 60, seconds % 60)
}
