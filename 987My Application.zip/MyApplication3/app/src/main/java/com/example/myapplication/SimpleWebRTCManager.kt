package com.example.myapplication.webrtc

import android.content.Context
import android.media.AudioManager
import android.util.Log
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import org.webrtc.*

class SimpleWebRTCManager(
    private val context: Context,
    private val currentUserId: String,
    private val remoteUserId: String
) {
    private val TAG = "WebRTCManager"
    private val db = FirebaseFirestore.getInstance()

    // ID документа звонка
    private val callId = if (currentUserId < remoteUserId)
        "${currentUserId}_${remoteUserId}"
    else
        "${remoteUserId}_${currentUserId}"

    var onCallEstablished: (() -> Unit)? = null
    var onCallEnded: (() -> Unit)? = null

    private var peerConnectionFactory: PeerConnectionFactory? = null
    private var peerConnection: PeerConnection? = null
    private var localAudioTrack: AudioTrack? = null

    // ВАЖНО: Храним предложение звонка здесь, пока пользователь не нажмет "Принять"
    private var pendingOfferSdp: String? = null

    private var signalingListener: ListenerRegistration? = null
    private var candidatesListener: ListenerRegistration? = null

    private val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private var savedAudioMode = audioManager.mode
    private var savedIsSpeakerPhoneOn = audioManager.isSpeakerphoneOn

    private val iceServers = listOf(
        PeerConnection.IceServer.builder("stun:stun.l.google.com:19302").createIceServer(),
        PeerConnection.IceServer.builder("stun:stun1.l.google.com:19302").createIceServer()
    )

    fun initialize() {
        Log.d(TAG, "🚀 Initialize WebRTC")

        // Очищаем старые настройки перед стартом
        pendingOfferSdp = null

        PeerConnectionFactory.initialize(
            PeerConnectionFactory.InitializationOptions.builder(context)
                .createInitializationOptions()
        )

        val options = PeerConnectionFactory.Options()
        peerConnectionFactory = PeerConnectionFactory.builder()
            .setOptions(options)
            .createPeerConnectionFactory()

        val constraints = MediaConstraints()
        val audioSource = peerConnectionFactory?.createAudioSource(constraints)
        localAudioTrack = peerConnectionFactory?.createAudioTrack("ARDAMSa0", audioSource)

        setupAudioManager()
        createPeerConnection()

        // Слушаем базу
        setupFirebaseListeners()
    }

    private fun setupAudioManager() {
        savedAudioMode = audioManager.mode
        savedIsSpeakerPhoneOn = audioManager.isSpeakerphoneOn
        audioManager.mode = AudioManager.MODE_IN_COMMUNICATION
        audioManager.isSpeakerphoneOn = false
    }

    fun toggleSpeaker(enable: Boolean) {
        audioManager.isSpeakerphoneOn = enable
    }

    fun toggleMute(mute: Boolean) {
        localAudioTrack?.setEnabled(!mute)
    }

    private fun createPeerConnection() {
        val rtcConfig = PeerConnection.RTCConfiguration(iceServers)
        rtcConfig.sdpSemantics = PeerConnection.SdpSemantics.UNIFIED_PLAN

        peerConnection = peerConnectionFactory?.createPeerConnection(rtcConfig, object : PeerConnection.Observer {
            override fun onIceCandidate(candidate: IceCandidate?) {
                candidate?.let { sendIceCandidate(it) }
            }
            override fun onAddStream(stream: MediaStream?) {
                Log.d(TAG, "onAddStream: Connected!")
                onCallEstablished?.invoke()
            }
            override fun onTrack(transceiver: RtpTransceiver?) {
                Log.d(TAG, "onTrack: Connected!")
                onCallEstablished?.invoke()
            }
            override fun onIceConnectionChange(newState: PeerConnection.IceConnectionState?) {
                Log.d(TAG, "State: $newState")
                if (newState == PeerConnection.IceConnectionState.DISCONNECTED ||
                    newState == PeerConnection.IceConnectionState.CLOSED) {
                    onCallEnded?.invoke()
                }
            }
            // Пустые методы
            override fun onSignalingChange(p0: PeerConnection.SignalingState?) {}
            override fun onIceConnectionReceivingChange(p0: Boolean) {}
            override fun onIceGatheringChange(p0: PeerConnection.IceGatheringState?) {}
            override fun onIceCandidatesRemoved(p0: Array<out IceCandidate>?) {}
            override fun onRemoveStream(p0: MediaStream?) {}
            override fun onDataChannel(p0: DataChannel?) {}
            override fun onRenegotiationNeeded() {}
            override fun onAddTrack(p0: RtpReceiver?, p1: Array<out MediaStream>?) {}
        })

        localAudioTrack?.let { peerConnection?.addTrack(it, listOf("ARDAMS")) }
    }

    // === ЗВОНКИ ===

    fun startCall() {
        // 1. Сначала удаляем старый мусор из базы!
        db.collection("calls").document(callId).delete().addOnCompleteListener {
            // 2. Только потом создаем новый звонок
            val constraints = MediaConstraints()
            peerConnection?.createOffer(object : SimpleSdpObserver() {
                override fun onCreateSuccess(desc: SessionDescription?) {
                    desc?.let {
                        peerConnection?.setLocalDescription(SimpleSdpObserver(), it)
                        sendSdp("OFFER", it.description)
                    }
                }
            }, constraints)
        }
    }

    fun acceptCall() {
        // ВАЖНО: Применяем сохраненный OFFER только когда нажали кнопку
        val offerSdp = pendingOfferSdp
        if (offerSdp == null) {
            Log.e(TAG, "❌ Ошибка: Нечего принимать (Offer is null)")
            return
        }

        Log.d(TAG, "✅ Применяем Offer и создаем Answer")

        peerConnection?.setRemoteDescription(SimpleSdpObserver(),
            SessionDescription(SessionDescription.Type.OFFER, offerSdp))

        val constraints = MediaConstraints()
        peerConnection?.createAnswer(object : SimpleSdpObserver() {
            override fun onCreateSuccess(desc: SessionDescription?) {
                desc?.let {
                    peerConnection?.setLocalDescription(SimpleSdpObserver(), it)
                    sendSdp("ANSWER", it.description)
                }
            }
        }, constraints)
    }

    fun endCall() {
        sendAction("END_CALL")
        cleanup()
    }

    // === FIREBASE ===

    private fun sendSdp(type: String, sdp: String) {
        val data = hashMapOf(
            "type" to type,
            "sdp" to sdp,
            "senderId" to currentUserId,
            "timestamp" to System.currentTimeMillis() // Важно для фильтрации старых звонков
        )
        db.collection("calls").document(callId).set(data)
    }

    private fun sendAction(type: String) {
        val data = hashMapOf(
            "type" to type,
            "senderId" to currentUserId,
            "timestamp" to System.currentTimeMillis()
        )
        db.collection("calls").document(callId).set(data)
    }

    private fun sendIceCandidate(candidate: IceCandidate) {
        val data = hashMapOf(
            "sdpMid" to candidate.sdpMid,
            "sdpMLineIndex" to candidate.sdpMLineIndex,
            "candidate" to candidate.sdp,
            "senderId" to currentUserId
        )
        db.collection("calls").document(callId).collection("candidates").add(data)
    }

    private fun setupFirebaseListeners() {
        signalingListener = db.collection("calls").document(callId)
            .addSnapshotListener { snapshot, e ->
                if (e != null || snapshot == null || !snapshot.exists()) return@addSnapshotListener

                val type = snapshot.getString("type")
                val sdp = snapshot.getString("sdp")
                val senderId = snapshot.getString("senderId")
                // Проверяем свежесть (не старше 60 сек), чтобы не ловить старые звонки
                val timestamp = snapshot.getLong("timestamp") ?: 0L
                val isFresh = (System.currentTimeMillis() - timestamp) < 60000

                if (senderId == currentUserId) return@addSnapshotListener

                when (type) {
                    "OFFER" -> {
                        if (isFresh) {
                            Log.d(TAG, "📥 Получен OFFER. Ждем нажатия кнопки...")
                            // ПРОСТО СОХРАНЯЕМ, НЕ ПРИМЕНЯЕМ!
                            pendingOfferSdp = sdp
                        }
                    }
                    "ANSWER" -> {
                        if (isFresh) {
                            Log.d(TAG, "📥 Получен ANSWER. Соединяемся...")
                            peerConnection?.setRemoteDescription(SimpleSdpObserver(),
                                SessionDescription(SessionDescription.Type.ANSWER, sdp))
                        }
                    }
                    "END_CALL" -> {
                        // END_CALL обрабатываем всегда, чтобы сбросить зависший звонок
                        onCallEnded?.invoke()
                    }
                }
            }

        candidatesListener = db.collection("calls").document(callId).collection("candidates")
            .addSnapshotListener { snapshots, e ->
                if (e != null) return@addSnapshotListener
                for (doc in snapshots!!.documentChanges) {
                    if (doc.type == com.google.firebase.firestore.DocumentChange.Type.ADDED) {
                        val senderId = doc.document.getString("senderId")
                        if (senderId == currentUserId) continue

                        val sdpMid = doc.document.getString("sdpMid")
                        val sdpMLineIndex = doc.document.getLong("sdpMLineIndex")?.toInt()
                        val sdp = doc.document.getString("candidate")

                        if (sdp != null) {
                            peerConnection?.addIceCandidate(IceCandidate(sdpMid, sdpMLineIndex ?: 0, sdp))
                        }
                    }
                }
            }
    }

    fun cleanup() {
        try {
            signalingListener?.remove()
            candidatesListener?.remove()
            audioManager.mode = savedAudioMode
            audioManager.isSpeakerphoneOn = savedIsSpeakerPhoneOn
            peerConnection?.close()
            peerConnection = null
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    open class SimpleSdpObserver : SdpObserver {
        override fun onCreateSuccess(p0: SessionDescription?) {}
        override fun onSetSuccess() {}
        override fun onCreateFailure(p0: String?) {}
        override fun onSetFailure(p0: String?) {}
    }
}
